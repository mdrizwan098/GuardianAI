# GuardianAI: Architecture & Engineering Specification

## 1. System Architecture Diagram

GuardianAI is structured into a multi-tiered, event-driven, privacy-preserving home safety architecture. Critical physical decisions are governed by a **Deterministic Safety Gate**, while AI provides perceptual intelligence (Computer Vision, Acoustic Analysis) and natural language triage (Multilingual LLM).

```mermaid
flowchart TD
    subgraph EdgeSensors["Edge & In-Home Sensors (IoT & Peripherals)"]
        CAM["IP / Web Cameras\n(RTSP / WebRTC)"]
        MIC["Microphone Array\n(Audio Stream)"]
        PIR["PIR Motion / Door Sensors"]
        SMOKE["Smoke / Gas Detectors"]
        ENV["Temp / Humidity Sensors"]
    end

    subgraph PerceptionLayer["Multimodal Perception Engine"]
        CV["Computer Vision Worker\n(Fall Detection & Motion Vectors)"]
        AUDIO["Audio Event Classifier\n(Glass Break, Screams, Distress Cries)"]
        FUSION["Sensor Fusion Aggregator\n(Correlation & Debounce)"]
    end

    subgraph CoreEngine["GuardianAI Core Engine (Node.js / Express / Socket.io)"]
        EVENT_BUS["Event Ingestion & Validation Gateway"]
        RISK_ASSESS["Risk Assessment Engine\n(Threat Matrix & Confidence Scorer)"]
        SAFETY_GATE{"Deterministic\nSafety Gate\n(Hard Rules Engine)"}
        ESCALATION["Emergency State Machine\n(L1 Info, L2 Warning, L3 Critical)"]
        TIMER["Escalation Countdown Manager"]
        AUDIT["Immutable Audit Logger"]
    end

    subgraph AITriageLayer["AI Conversational & Advisory Layer"]
        LLM["Multilingual LLM Triage Agent\n(English, Hindi, Hinglish)"]
        STT_TTS["Speech-to-Text & Calm TTS Engine"]
        MEM["Household Context & Medical Directives"]
    end

    subgraph StorageLayer["Data & Persistence Layer"]
        MONGO[("MongoDB\n14 Schema Collections")]
        REDIS[("Redis / In-Memory State Cache\n(Active Alerts & Sessions)")]
        EVIDENCE["Secure Ephemeral Evidence Store\n(Auto-Purge Retention)"]
    end

    subgraph CommunicationLayer["Dispatch & Communication Gateway"]
        WEBRTC_SIG["WebRTC Signaling Hub\n(Live Video & Audio)"]
        NOTIF_SVC["Multi-Channel Notification Dispatcher\n(Push, Webhook, SMS Simulator)"]
        EMERG_DISPATCH["Emergency 112 / Doctor Dispatch Adapter\n(Live API / Audited Simulation)"]
    end

    subgraph UserInterface["Client Applications (React / Tailwind SOC Dashboard)"]
        SOC["Security Operations Center (SOC) Dashboard"]
        FAMILY_PORTAL["Family Connection & Video Call HUD"]
        VOICE_HUD["Interactive Voice & Audio Console"]
        PRIVACY_HUD["Privacy & Consent Controller"]
    end

    %% Connections
    CAM --> CV
    MIC --> AUDIO
    PIR --> FUSION
    SMOKE --> FUSION
    ENV --> FUSION
    CV --> FUSION
    AUDIO --> FUSION

    FUSION --> EVENT_BUS
    EVENT_BUS --> RISK_ASSESS
    RISK_ASSESS --> SAFETY_GATE
    SAFETY_GATE --> ESCALATION

    ESCALATION <--> TIMER
    ESCALATION --> NOTIF_SVC
    ESCALATION --> EMERG_DISPATCH
    ESCALATION --> LLM

    LLM <--> STT_TTS
    LLM <--> MEM
    STT_TTS <--> VOICE_HUD

    SAFETY_GATE --> AUDIT
    AUDIT --> MONGO
    ESCALATION --> REDIS
    EVENT_BUS --> MONGO
    FUSION --> EVIDENCE

    WEBRTC_SIG <--> FAMILY_PORTAL
    EVENT_BUS <--> SOC
    PRIVACY_HUD --> SAFETY_GATE
```

---

## 2. Detailed Folder Structure

```
GuardianAI/
├── docs/
│   └── ARCHITECTURE_SPEC.md              # System specification & API blueprint
├── backend/
│   ├── src/
│   │   ├── config/
│   │   │   ├── database.js               # MongoDB (Native / Memory Server) setup
│   │   │   ├── cache.js                  # Redis / In-memory fallback adapter
│   │   │   ├── socket.js                 # WebSockets & WebRTC signaling config
│   │   │   └── env.js                    # Validated environment configuration
│   │   ├── models/                       # 14 Mongoose Schema Definitions
│   │   │   ├── User.js
│   │   │   ├── Household.js
│   │   │   ├── FamilyMember.js
│   │   │   ├── EmergencyContact.js
│   │   │   ├── Device.js
│   │   │   ├── CameraDevice.js
│   │   │   ├── SensorEvent.js
│   │   │   ├── EmergencyEvent.js
│   │   │   ├── RiskAssessment.js
│   │   │   ├── Notification.js
│   │   │   ├── Call.js
│   │   │   ├── ConsentRecord.js
│   │   │   ├── AutomationRule.js
│   │   │   └── AuditLog.js
│   │   ├── routes/
│   │   │   ├── authRoutes.js
│   │   │   ├── householdRoutes.js
│   │   │   ├── familyRoutes.js
│   │   │   ├── contactRoutes.js
│   │   │   ├── deviceRoutes.js
│   │   │   ├── eventRoutes.js
│   │   │   ├── aiRoutes.js
│   │   │   ├── emergencyRoutes.js
│   │   │   ├── callRoutes.js
│   │   │   ├── consentRoutes.js
│   │   │   └── auditRoutes.js
│   │   ├── services/
│   │   │   ├── aiTriageService.js        # Multilingual conversational triage (EN/HI/Hinglish)
│   │   │   ├── escalationEngine.js       # Deterministic safety rule & escalation manager
│   │   │   ├── sensorFusionService.js    # Multi-sensor correlation & debouncing
│   │   │   ├── notificationService.js    # Multi-channel notification dispatch
│   │   │   ├── emergencyDispatchService.js # 112 / Police / Ambulance dispatcher adapter
│   │   │   ├── webrtcSignalingService.js # WebRTC signaling & peer matching
│   │   │   └── auditService.js           # Tamper-evident logging
│   │   ├── middleware/
│   │   │   ├── authMiddleware.js         # JWT verification & claims validation
│   │   │   ├── rbacMiddleware.js         # Role-based access control
│   │   │   ├── privacyMiddleware.js      # Privacy mode and consent enforcement
│   │   │   └── errorHandler.js           # Centralized API error handler
│   │   └── index.js                      # Main HTTP & WebSocket server entrypoint
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── public/
│   │   └── audio/                        # Calm warning chimes and alerts
│   ├── src/
│   │   ├── assets/
│   │   ├── components/
│   │   │   ├── common/
│   │   │   │   ├── Header.jsx
│   │   │   │   ├── Sidebar.jsx
│   │   │   │   ├── StatusBadge.jsx
│   │   │   │   └── ConfirmationModal.jsx
│   │   │   ├── dashboard/
│   │   │   │   ├── OverviewMetrics.jsx
│   │   │   │   ├── QuickStatusGrid.jsx
│   │   │   │   └── ActiveThreatBanner.jsx
│   │   │   ├── liveMonitoring/
│   │   │   │   ├── CameraFeedPlayer.jsx
│   │   │   │   ├── VisionFallDetector.jsx  # Client-side fall detection & posture kinematics
│   │   │   │   ├── AudioDistressDetector.jsx # Mic listener for distress & noise spikes
│   │   │   │   └── SensorMatrix.jsx
│   │   │   ├── emergency/
│   │   │   │   ├── EmergencyCenterHUD.jsx  # Active emergency manager & countdown
│   │   │   │   ├── TriageDialogue.jsx     # "Are you okay?" interactive voice/text dialog
│   │   │   │   ├── DispatchActionCard.jsx # 112 / Doctor / Family dispatcher
│   │   │   │   └── ManualSosButton.jsx
│   │   │   ├── family/
│   │   │   │   ├── FamilyMemberDirectory.jsx
│   │   │   │   ├── ContactPriorityEditor.jsx
│   │   │   │   └── WebRTCVideoRoom.jsx    # Real-time peer-to-peer / loopback video calling
│   │   │   ├── aiAssistant/
│   │   │   │   ├── VoiceConsole.jsx       # Bilingual EN/HI voice recognition & speech
│   │   │   │   └── ConversationalTranscript.jsx
│   │   │   ├── devices/
│   │   │   │   ├── DeviceManager.jsx
│   │   │   │   └── IoTEventSimulator.jsx  # Test harness for triggering sensor incidents
│   │   │   ├── audit/
│   │   │   │   ├── AuditLogViewer.jsx
│   │   │   │   └── IncidentReportGenerator.jsx
│   │   │   └── privacy/
│   │   │       ├── PrivacyModeToggle.jsx
│   │   │       ├── ConsentSettings.jsx
│   │   │       └── RetentionPolicyConfig.jsx
│   │   ├── context/
│   │   │   ├── AuthContext.jsx
│   │   │   ├── SocketContext.jsx
│   │   │   ├── EmergencyContext.jsx
│   │   │   └── PrivacyContext.jsx
│   │   ├── hooks/
│   │   │   ├── useWebRTC.js
│   │   │   ├── useVoiceAssistant.js
│   │   │   └── useSensorStream.js
│   │   ├── services/
│   │   │   ├── api.js
│   │   │   └── socket.js
│   │   ├── styles/
│   │   │   └── index.css
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
└── package.json (root scripts for monorepo dev)
```

---

## 3. Technology Selection with Reasoning

| Component | Selected Technology | Architectural Reasoning |
| :--- | :--- | :--- |
| **Backend Runtime** | Node.js (v20+) & Express.js | Low-latency I/O handling for sensor telemetry and socket connections; rapid JSON serialization; unified JS/TS ecosystem across edge and cloud. |
| **Real-time Transport** | Socket.io & WebRTC | Sub-50ms bidirectional state synchronization for emergency alerts, sensor telemetry streaming, and peer-to-peer family video/audio communication. |
| **Primary Database** | MongoDB (Mongoose ODM) | Flexible document schema for varying sensor telemetry payloads, nested risk assessments, and polymorphic audit entries. Embedded fallback provided for seamless zero-dependency deployment. |
| **Transient State Cache** | Redis / In-Memory State Cache | Sub-millisecond read/write for active countdown timers, idempotency keys, and socket session registries. Fallback to robust memory store when standalone Redis is unconfigured. |
| **Frontend Framework** | React 18+ & Vite | High-performance reactive rendering with optimized virtual DOM for real-time sensor streams and low-latency WebRTC rendering. |
| **UI Design System** | Tailwind CSS & Lucide Icons | Rapid creation of a sleek, Tesla/Apple SOC dark theme (Deep Navy `#0B1120`, Dark Charcoal `#111827`, Electric Blue `#3B82F6`, Soft Cyan `#06B6D4`, Alert Red `#EF4444`). |
| **Computer Vision** | In-browser & Server Kinematics | Real-time posture tracking analyzing bounding box aspect ratio transitions, centroid descent velocity, and floor plane dwell time without transmitting private video frames to external third parties. |
| **Audio Processing** | Web Audio API Spectral Analyzer | Frequency decomposition (FFT) for alarm tone detection (3kHz fire alarm beeps), sudden decibel delta spikes, and vocal distress acoustic envelopes. |
| **Conversational AI** | Hybrid Engine (Multilingual LLM + Deterministic Clinical Triage) | Fast, calm triage in English, Hindi, and Hinglish. Crucially, the LLM provides consultative conversation, while deterministic rules enforce safety actions and prevent hallucinations. |
| **Telephony & Dispatch** | Modular Dispatcher (Live Webhooks + Audited Simulation) | Implements standardized Emergency 112 (India/EU) and Twilio SMS/Voice protocols with guaranteed simulation fallback that never misleads the operator. |

---

## 4. Complete Database Schemas (14 Entities)

### 1. `User`
```json
{
  "_id": "ObjectId",
  "name": "String (required)",
  "email": "String (required, unique, indexed)",
  "passwordHash": "String (required)",
  "phone": "String (required)",
  "role": { "type": "String", "enum": ["admin", "family_member", "elderly_caregiver", "child"], "default": "family_member" },
  "householdId": "ObjectId (ref: Household, indexed)",
  "preferredLanguage": { "type": "String", "enum": ["en", "hi", "hinglish"], "default": "en" },
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### 2. `Household`
```json
{
  "_id": "ObjectId",
  "name": "String (required)",
  "address": {
    "street": "String",
    "city": "String",
    "state": "String",
    "postalCode": "String",
    "country": { "type": "String", "default": "IN" },
    "coordinates": { "latitude": "Number", "longitude": "Number" }
  },
  "emergencyServiceNumber": { "type": "String", "default": "112" },
  "privacyModeActive": { "type": "Boolean", "default": false },
  "safeRoomLocation": "String",
  "createdAt": "Date"
}
```

### 3. `FamilyMember`
```json
{
  "_id": "ObjectId",
  "householdId": "ObjectId (ref: Household, indexed)",
  "userId": "ObjectId (ref: User, nullable)",
  "fullName": "String (required)",
  "relationship": { "type": "String", "enum": ["parent", "child", "spouse", "sibling", "caregiver", "other"] },
  "isChild": { "type": "Boolean", "default": false },
  "age": "Number",
  "medicalConditions": ["String"],
  "emergencyPriority": "Number (1-5, 1 being highest)",
  "availabilityStatus": { "type": "String", "enum": ["home", "away", "busy", "offline"], "default": "home" },
  "avatarUrl": "String"
}
```

### 4. `EmergencyContact`
```json
{
  "_id": "ObjectId",
  "householdId": "ObjectId (ref: Household, indexed)",
  "name": "String (required)",
  "relationship": "String",
  "phone": "String (required)",
  "email": "String",
  "contactType": { "type": "String", "enum": ["family", "doctor", "neighbor", "police", "ambulance"], "default": "family" },
  "priorityOrder": "Number (required)",
  "notifyViaSms": { "type": "Boolean", "default": true },
  "notifyViaCall": { "type": "Boolean", "default": true }
}
```

### 5. `Device`
```json
{
  "_id": "ObjectId",
  "householdId": "ObjectId (ref: Household, indexed)",
  "deviceName": "String (required)",
  "deviceType": { "type": "String", "enum": ["camera", "motion_sensor", "door_contact", "smoke_alarm", "glass_sensor", "environmental", "smart_hub"] },
  "location": "String (e.g., Living Room, Front Door)",
  "ipAddress": "String",
  "macAddress": "String",
  "isOnline": { "type": "Boolean", "default": true },
  "lastHeartbeat": "Date",
  "batteryLevel": "Number",
  "firmwareVersion": "String"
}
```

### 6. `CameraDevice`
```json
{
  "_id": "ObjectId",
  "deviceId": "ObjectId (ref: Device, required, unique)",
  "householdId": "ObjectId (ref: Household, indexed)",
  "streamUrl": "String",
  "rtspEndpoint": "String",
  "resolution": "String",
  "hasPtz": { "type": "Boolean", "default": false },
  "isPrivacyMasked": { "type": "Boolean", "default": false },
  "recordingEnabled": { "type": "Boolean", "default": false },
  "fps": { "type": "Number", "default": 30 }
}
```

### 7. `SensorEvent`
```json
{
  "_id": "ObjectId",
  "householdId": "ObjectId (ref: Household, indexed)",
  "deviceId": "ObjectId (ref: Device, indexed)",
  "eventType": { "type": "String", "enum": ["motion", "door_open", "door_forced", "glass_break", "smoke_detected", "temperature_spike", "audio_distress", "fall_detected"] },
  "timestamp": { "type": "Date", "default": "Date.now", "indexed": true },
  "rawConfidence": "Number",
  "telemetryData": "Schema.Types.Mixed",
  "isProcessed": { "type": "Boolean", "default": false }
}
```

### 8. `EmergencyEvent`
```json
{
  "_id": "ObjectId",
  "eventId": { "type": "String", "unique": true, "indexed": true },
  "householdId": "ObjectId (ref: Household, indexed)",
  "eventType": { "type": "String", "enum": ["medical_fall", "unresponsive_person", "intrusion_attempt", "fire_hazard", "distress_call", "panic_button"] },
  "detectionTimestamp": { "type": "Date", "default": "Date.now" },
  "sourceDevice": "ObjectId (ref: Device)",
  "riskClassification": { "type": "String", "enum": ["LEVEL_1_INFO", "LEVEL_2_WARNING", "LEVEL_3_CRITICAL"], "required": true },
  "confidenceScore": "Number (0.00 - 1.00)",
  "verificationStatus": { "type": "String", "enum": ["unverified", "awaiting_user", "user_confirmed_safe", "user_confirmed_help", "timed_out_escalated", "false_alarm"], "default": "unverified" },
  "actionsInitiated": [{
    "action": "String",
    "timestamp": "Date",
    "status": "String",
    "recipient": "String"
  }],
  "notificationStatus": { "type": "String", "enum": ["pending", "dispatched", "acknowledged", "failed"] },
  "resolutionStatus": { "type": "String", "enum": ["active", "escalated", "resolved", "dismissed"], "default": "active" },
  "resolvedAt": "Date",
  "resolvedBy": "String"
}
```

### 9. `RiskAssessment`
```json
{
  "_id": "ObjectId",
  "emergencyEventId": "ObjectId (ref: EmergencyEvent, indexed)",
  "householdId": "ObjectId (ref: Household)",
  "assessedLevel": { "type": "String", "enum": ["LEVEL_1_INFO", "LEVEL_2_WARNING", "LEVEL_3_CRITICAL"] },
  "confidenceScore": "Number",
  "primarySignals": [{
    "sensorType": "String",
    "signalValue": "String",
    "confidence": "Number"
  }],
  "corroboratingSignals": [{
    "sensorType": "String",
    "signalValue": "String"
  }],
  "aiReasoningSummary": "String",
  "deterministicRuleTriggered": "String",
  "evaluatedAt": "Date"
}
```

### 10. `Notification`
```json
{
  "_id": "ObjectId",
  "householdId": "ObjectId (ref: Household, indexed)",
  "emergencyEventId": "ObjectId (ref: EmergencyEvent, indexed)",
  "recipientName": "String",
  "recipientPhone": "String",
  "channel": { "type": "String", "enum": ["sms", "voice_call", "push", "webrtc_alert", "emergency_dispatch"] },
  "status": { "type": "String", "enum": ["queued", "sent", "delivered", "failed", "simulated"], "default": "queued" },
  "dispatchTimestamp": "Date",
  "deliveryReceipt": "String",
  "retryCount": { "type": "Number", "default": 0 }
}
```

### 11. `Call`
```json
{
  "_id": "ObjectId",
  "householdId": "ObjectId (ref: Household, indexed)",
  "callerId": "ObjectId (ref: User)",
  "receiverId": "ObjectId (ref: User)",
  "callType": { "type": "String", "enum": ["family_video", "family_voice", "emergency_auto_call", "doctor_consult"] },
  "sessionToken": "String",
  "status": { "type": "String", "enum": ["initiated", "ringing", "connected", "ended", "missed", "rejected"] },
  "startedAt": "Date",
  "endedAt": "Date",
  "durationSeconds": "Number"
}
```

### 12. `ConsentRecord`
```json
{
  "_id": "ObjectId",
  "householdId": "ObjectId (ref: Household, indexed)",
  "userId": "ObjectId (ref: User)",
  "cameraConsent": { "type": "Boolean", "default": true },
  "microphoneConsent": { "type": "Boolean", "default": true },
  "biometricFallConsent": { "type": "Boolean", "default": true },
  "emergencyDispatchConsent": { "type": "Boolean", "default": true },
  "dataRetentionDays": { "type": "Number", "default": 7 },
  "lastSignedAt": "Date",
  "ipAddress": "String"
}
```

### 13. `AutomationRule`
```json
{
  "_id": "ObjectId",
  "householdId": "ObjectId (ref: Household, indexed)",
  "ruleName": "String (required)",
  "triggerEventType": "String",
  "conditionThreshold": { "confidenceMin": "Number", "durationSeconds": "Number" },
  "targetAction": "String",
  "priorityLevel": "String",
  "isEnabled": { "type": "Boolean", "default": true }
}
```

### 14. `AuditLog`
```json
{
  "_id": "ObjectId",
  "householdId": "ObjectId (ref: Household, indexed)",
  "action": "String (required)",
  "actor": "String (system | user | ai_assistant)",
  "ipAddress": "String",
  "details": "Schema.Types.Mixed",
  "hash": "String (cryptographic checksum for tamper detection)",
  "timestamp": { "type": "Date", "default": "Date.now", "indexed": true }
}
```

---

## 5. API Endpoint Documentation

| Method | Endpoint | Description | RBAC Role |
| :--- | :--- | :--- | :--- |
| **POST** | `/api/auth/register` | Register primary household user | Public |
| **POST** | `/api/auth/login` | Authenticate user & return JWT | Public |
| **GET** | `/api/auth/me` | Fetch active profile & household details | Authenticated |
| **GET** | `/api/households` | Get household settings & state | Family Member+ |
| **PATCH** | `/api/households/privacy-mode` | Toggle Privacy Mode (blinds cameras/mics) | Admin / Family |
| **GET** | `/api/family` | List family members & live status | Family Member+ |
| **POST** | `/api/family` | Add a new family member | Admin |
| **PATCH** | `/api/family/:id/status` | Update availability status (Home, Away, Busy) | Self / Admin |
| **GET** | `/api/contacts` | Retrieve emergency contacts list | Family Member+ |
| **POST** | `/api/contacts` | Add emergency contact with priority | Admin |
| **GET** | `/api/devices` | List connected devices & health telemetry | Family Member+ |
| **POST** | `/api/devices/telemetry` | Ingest real-time IoT & sensor telemetry | Device / System |
| **POST** | `/api/events/detect` | Ingest CV/Audio detected incident | System / Camera |
| **POST** | `/api/ai/triage` | Submit speech/text for multimodal emergency triage | All |
| **GET** | `/api/emergency/active` | Get current active emergencies & countdowns | All |
| **POST** | `/api/emergency/confirm` | User responds: "Safe" or "Need Help" | All |
| **POST** | `/api/emergency/escalate` | Force escalation to Level 3 / Emergency 112 | All |
| **POST** | `/api/emergency/dispatch-112`| Execute 112 / Police / Ambulance dispatch | System / Admin |
| **POST** | `/api/calls/initiate` | Initiate WebRTC family video/audio call | Family Member |
| **GET** | `/api/audit` | Fetch immutable audit logs | Admin |
| **GET** | `/api/consent` | Fetch active privacy & consent configuration | All |

---

## 6. AI Model Selection & Pipeline

1. **Computer Vision (Fall & Posture Kinematics)**
   - **Engine**: MoveNet Lightning / PoseNet on browser edge + Server-side bounding box aspect ratio analyzer.
   - **Kinematic Rule**: Detects sudden vertical centroid displacement ($> 1.2 m/s$) followed by horizontal bounding box ratio ($W/H > 1.4$) on the floor plane exceeding 10 seconds of motionless dwell time.
   - **Privacy Boundary**: Video frames are processed strictly in local device memory. Only anonymized kinematic vectors (e.g., `centroid_velocity`, `posture_angle`) are transmitted to the server.

2. **Acoustic Distress Classifier**
   - **Engine**: Local Spectral Fast Fourier Transform (FFT) Analyzer & Keyword Spotter.
   - **Target Signatures**:
     - Fire/Smoke Alarms: Repeated high-pitch tone pulses at $3000\text{--}3200\text{ Hz}$.
     - Glass Break: High-frequency transient spikes $> 4500\text{ Hz}$ with sharp decay.
     - Distress Vocalizations: "Help me", "Save me", "Bachao", "Koi hai", screaming envelopes.

3. **Multilingual Conversational Triage (LLM + Local Deterministic Fallback)**
   - **Languages**: English, Hindi (हिन्दी), and Hinglish.
   - **Role**: Conducts calm, empathetic triage ("Are you okay? Do you need medical help? / Aap theek hain? Kya main emergency contacts ko call karun?").
   - **Deterministic Guardrail**: Conversational output cannot cancel a verified fire alarm or prevent automated 112 dispatch if user is unresponsive.

---

## 7. Event Processing Workflow

```mermaid
sequenceDiagram
    autonumber
    participant Sensor as IP Camera / IoT Sensor
    participant Gateway as Event Ingestion Gateway
    participant Fusion as Sensor Fusion Engine
    participant Gate as Deterministic Safety Gate
    participant Triage as Multilingual AI Assistant
    participant Escalate as Escalation Engine
    participant Family as Family / Emergency Contacts
    participant Dispatch as 112 Emergency Dispatch

    Sensor->>Gateway: POST /api/events/detect (Fall / Breach / Fire)
    Gateway->>Fusion: Correlate with secondary sensors (Motion, Sound)
    Fusion->>Gate: Compute Risk Score & Category (L1 / L2 / L3)
    
    alt LEVEL 2 (Warning - e.g., Fall Detected)
        Gate->>Triage: Trigger Voice Challenge ("Are you alright?")
        Triage->>Sensor: Audio: "Are you okay? Do you need help?"
        
        alt User responds: "I am fine / Main theek hoon"
            Sensor->>Triage: Voice response "I am fine"
            Triage->>Gate: Log Verification (Resolved as Safe)
            Gate->>Family: Send notification: Fall checked, user confirmed safe
        else User unresponsive (Countdown Expiry: 30s)
            Gate->>Escalate: Escalate to LEVEL 3 CRITICAL
            Escalate->>Family: Automated Emergency Video/Voice Call & SMS
            Escalate->>Dispatch: Dispatch 112 Ambulance with GPS location & medical profile
        end

    else LEVEL 3 (Critical - Confirmed Fire / Panic SOS)
        Gate->>Escalate: Immediate Critical Escalation
        Escalate->>Family: Blast SMS & Push notifications
        Escalate->>Dispatch: Notify 112 Fire/Rescue Dispatch
    end
```

---

## 8. Emergency Escalation Logic & Matrix

| Emergency Level | Trigger Conditions | Required Confidence | User Confirmation Window | Automated Actions | Escalation Route |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **LEVEL 1: INFORMATIONAL** | Minor sensor anomaly, routine door open during scheduled hour, low battery. | $> 60\%$ | None (Informational only) | Log to dashboard, push non-intrusive notification. | No escalation unless repeated within 5 min. |
| **LEVEL 2: WARNING** | Possible fall detected, unexpected night door opening, loud glass break sound. | $> 75\%$ single sensor or $65\%$ correlated | 30 Seconds countdown with audible "Are you okay?" prompt. | Flash dashboard warning, announce voice challenge, notify primary family contact. | If no response or user asks for help $\to$ auto-escalate to Level 3. |
| **LEVEL 3: CRITICAL** | Confirmed smoke/fire alarm, fall with unresponsive victim $> 30\text{s}$, forced entry breach, manual SOS pressed. | $> 90\%$ single or $80\%$ dual-sensor confirmation | 15 Seconds panic abort window (prevents accidental dispatch) | Activate local audible siren, notify all emergency contacts via SMS/Voice, initiate emergency video link. | Dispatch Emergency 112 / Police / Ambulance with coordinates & medical history. |

---

## 9. Security & Privacy Architecture

1. **Hardware-Level Privacy Mode**:
   - Activating Privacy Mode physically and cryptographically halts camera and microphone data streaming. Visible UI badges and physical hardware state alerts confirm privacy status.
2. **Ephemeral Evidence & Strict Retention**:
   - No continuous raw video recording. Only 15-second pre- and post-incident sensor kinematic snapshots are retained during an active emergency event, encrypted at rest with AES-256 and purged automatically after user-configured retention days.
3. **Role-Based Access Control (RBAC)**:
   - `admin`: Full configuration, user addition, camera access, audit inspection.
   - `family_member`: Video calling, view alerts, receive notifications.
   - `elderly_caregiver`: Access to health alerts and direct voice connection.
   - `child`: Protected restricted view with guardian-managed permissions; no remote camera controls.
4. **Tamper-Evident Audit Trails**:
   - Every emergency activation, dispatch, video stream session, and privacy toggle generates a SHA-256 chained log entry stored in the `AuditLog` collection.

---

## 10. MVP Development Roadmap

- **Phase 1: Working Core Foundation & MVP**
  - Full backend infrastructure (Express, MongoDB memory/native adapter, Socket.io, JWT auth, RBAC).
  - High-tech SOC Dashboard UI with Apple Home/Tesla dark theme.
  - Family directory & Emergency Contacts manager with priority ordering.
  - Manual SOS Trigger and Interactive Multilingual AI Voice Assistant (English & Hindi/Hinglish).
  - Clear Simulation Mode for Indian Emergency 112 & SMS notifications.

- **Phase 2: Intelligent Multimodal Detection Engine**
  - Live browser camera feed with client-side fall detection kinematic analyzer.
  - Live microphone listener for acoustic distress and alarm frequency spikes.
  - IoT Sensor Telemetry Simulator (door forced, glass break, smoke alarm, motion).
  - Deterministic Safety Gate and Multimodal Risk Assessment Engine.

- **Phase 3: Emergency Escalation & Automated Response**
  - Dynamic 3-Level Escalation state machine with interactive 30-second countdown.
  - "Are you okay?" voice/dialogue verification workflow with emergency abort/confirm.
  - Automated Doctor and Emergency 112 Dispatch workflows with audit logs.

- **Phase 4: Real-Time Family Communication**
  - WebRTC family video & audio calling interface with real-time signaling.
  - Emergency live video link initiation during active distress alerts.

- **Phase 5: Privacy Controls, Audit Trails & Hardening**
  - Privacy Mode toggle with active sensor indicators.
  - Configurable data retention and cryptographic audit log viewer.
  - End-to-end integration testing and production readiness validation.

