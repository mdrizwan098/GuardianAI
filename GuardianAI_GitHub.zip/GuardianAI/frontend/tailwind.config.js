/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#060A12',
          900: '#0B1120',
          850: '#0E172A',
          800: '#14213D',
        },
        charcoal: {
          900: '#111827',
          800: '#1F2937',
          700: '#374151'
        },
        electric: {
          500: '#3B82F6',
          600: '#2563EB',
          700: '#1D4ED8'
        },
        cyanGlow: {
          400: '#22D3EE',
          500: '#06B6D4',
          600: '#0891B2'
        },
        alert: {
          500: '#EF4444',
          600: '#DC2626',
          700: '#B91C1C'
        }
      },
      animation: {
        'pulse-fast': 'pulse 1s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'ping-slow': 'ping 2s cubic-bezier(0, 0, 0.2, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        glow: {
          '0%': { boxShadow: '0 0 10px rgba(6, 182, 212, 0.3)' },
          '100%': { boxShadow: '0 0 25px rgba(6, 182, 212, 0.7)' },
        }
      }
    },
  },
  plugins: [],
}

