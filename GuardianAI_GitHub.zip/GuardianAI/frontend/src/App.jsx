import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import { EmergencyProvider } from './context/EmergencyContext';
import { PrivacyProvider } from './context/PrivacyContext';

import { Header } from './components/common/Header';
import { NavigationTabs } from './components/common/NavigationTabs';
import { TriageDialogue } from './components/emergency/TriageDialogue';

import { OverviewMetrics } from './components/dashboard/OverviewMetrics';
import { VisionFallDetector } from './components/liveMonitoring/VisionFallDetector';
import { AudioDistressDetector } from './components/liveMonitoring/AudioDistressDetector';
import { EmergencyCenterHUD } from './components/emergency/EmergencyCenterHUD';
import { FamilyMemberDirectory } from './components/family/FamilyMemberDirectory';
import { VoiceConsole } from './components/aiAssistant/VoiceConsole';
import { IoTEventSimulator } from './components/devices/IoTEventSimulator';

function DashboardContent() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="min-h-screen bg-navy-950 text-slate-100 flex flex-col">
      {/* Header */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Tabs */}
      <NavigationTabs activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Interactive Triage Modal (Level 2 Warning) */}
      <TriageDialogue />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'overview' && (
          <OverviewMetrics setActiveTab={setActiveTab} />
        )}

        {activeTab === 'monitoring' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <VisionFallDetector />
            <AudioDistressDetector />
          </div>
        )}

        {activeTab === 'emergency' && (
          <EmergencyCenterHUD />
        )}

        {activeTab === 'family' && (
          <FamilyMemberDirectory />
        )}

        {activeTab === 'ai_assistant' && (
          <VoiceConsole />
        )}

        {activeTab === 'iot_audit' && (
          <IoTEventSimulator />
        )}
      </main>

      {/* Futuristic SOC Footer */}
      <footer className="w-full border-t border-slate-900 bg-navy-950/80 px-4 py-4 text-center text-xs font-mono text-slate-500 flex flex-wrap items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-cyan-400" />
          <span>GuardianAI Core Sentry • Hybrid Deterministic Safety Engine</span>
        </div>
        <div className="flex items-center gap-4 mt-2 sm:mt-0">
          <span>ERSS 112 Protocol (IN/EU)</span>
          <span>•</span>
          <span>Zero-Knowledge Optical Privacy</span>
          <span>•</span>
          <span>AES-256 Storage</span>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <SocketProvider>
        <PrivacyProvider>
          <EmergencyProvider>
            <DashboardContent />
          </EmergencyProvider>
        </PrivacyProvider>
      </SocketProvider>
    </AuthProvider>
  );
}

