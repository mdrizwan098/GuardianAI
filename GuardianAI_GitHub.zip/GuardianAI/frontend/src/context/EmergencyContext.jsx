import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';
import { useSocket } from './SocketContext';

const EmergencyContext = createContext(null);

export const EmergencyProvider = ({ children }) => {
  const { socket } = useSocket();
  const [activeEmergency, setActiveEmergency] = useState(null);
  const [countdown, setCountdown] = useState(0);
  const [riskAssessment, setRiskAssessment] = useState(null);
  const [showTriageDialog, setShowTriageDialog] = useState(false);
  const [voiceChallengeText, setVoiceChallengeText] = useState('');
  const [dispatchResult, setDispatchResult] = useState(null);
  const [audioAlertActive, setAudioAlertActive] = useState(false);

  const fetchActive = async () => {
    try {
      const data = await api.getActiveEmergency();
      if (data.active && data.event) {
        setActiveEmergency(data.event);
        setCountdown(data.countdown || 0);
        setRiskAssessment(data.riskAssessment || null);
        if (data.event.riskClassification === 'LEVEL_2_WARNING') {
          setShowTriageDialog(true);
        }
      } else {
        setActiveEmergency(null);
        setCountdown(0);
        setShowTriageDialog(false);
      }
    } catch (err) {
      console.warn('Could not fetch active emergency:', err.message);
    }
  };

  useEffect(() => {
    fetchActive();
  }, []);

  // Real-time socket event listeners
  useEffect(() => {
    if (!socket) return;

    socket.on('emergency:new', (data) => {
      console.log('[Emergency Alert Received]', data);
      setActiveEmergency(data.event);
      setCountdown(data.countdown || 0);
      setAudioAlertActive(true);

      if (data.event.riskClassification === 'LEVEL_2_WARNING') {
        setShowTriageDialog(true);
        setVoiceChallengeText(data.voiceChallenge || 'Are you alright? Do you need medical help?');
      } else if (data.event.riskClassification === 'LEVEL_3_CRITICAL') {
        setShowTriageDialog(false);
      }
    });

    socket.on('emergency:countdown_tick', ({ eventId, remainingSeconds, level }) => {
      setCountdown(remainingSeconds);
    });

    socket.on('emergency:escalated', (data) => {
      console.log('[Emergency Escalated to Level 3]', data);
      setShowTriageDialog(false);
      fetchActive();
    });

    socket.on('emergency:resolved', (data) => {
      console.log('[Emergency Resolved]', data);
      setActiveEmergency(null);
      setCountdown(0);
      setShowTriageDialog(false);
      setAudioAlertActive(false);
      setDispatchResult(null);
    });

    return () => {
      socket.off('emergency:new');
      socket.off('emergency:countdown_tick');
      socket.off('emergency:escalated');
      socket.off('emergency:resolved');
    };
  }, [socket]);

  const confirmSafe = async (notes = '') => {
    if (!activeEmergency) return;
    try {
      await api.confirmEmergency(activeEmergency.eventId, true, notes);
      setShowTriageDialog(false);
      setActiveEmergency(null);
      setCountdown(0);
      setAudioAlertActive(false);
    } catch (err) {
      console.error('Failed to confirm safe:', err);
    }
  };

  const requestImmediateHelp = async (reason = 'Resident confirmed emergency need') => {
    if (!activeEmergency) return;
    try {
      setShowTriageDialog(false);
      const res = await api.escalateEmergency(activeEmergency.eventId, reason);
      const dispatch = await api.dispatch112(activeEmergency.eventId, 'ALL', reason);
      setDispatchResult(dispatch);
      fetchActive();
    } catch (err) {
      console.error('Failed to request help:', err);
    }
  };

  const triggerManualSOS = async (reason = 'Manual Emergency SOS Activated by User') => {
    try {
      const res = await api.escalateEmergency(null, reason);
      const dispatch = await api.dispatch112(res.event?._id, 'ALL', reason);
      setDispatchResult(dispatch);
      setActiveEmergency(res.event);
      setCountdown(15);
      setAudioAlertActive(true);
    } catch (err) {
      console.error('Failed to trigger manual SOS:', err);
    }
  };

  return (
    <EmergencyContext.Provider
      value={{
        activeEmergency,
        countdown,
        riskAssessment,
        showTriageDialog,
        voiceChallengeText,
        dispatchResult,
        audioAlertActive,
        confirmSafe,
        requestImmediateHelp,
        triggerManualSOS,
        refreshEmergency: fetchActive,
        setDispatchResult
      }}
    >
      {children}
    </EmergencyContext.Provider>
  );
};

export const useEmergency = () => useContext(EmergencyContext);

