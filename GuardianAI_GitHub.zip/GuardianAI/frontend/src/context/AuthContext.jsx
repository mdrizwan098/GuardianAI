import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [household, setHousehold] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = async () => {
    try {
      const data = await api.getMe();
      setUser(data.user);
      setHousehold(data.household);
    } catch (err) {
      console.warn('Auto-login defaulting to demo admin session:', err.message);
      // Fallback demo login
      try {
        const loginData = await api.login('aarav@guardianai.home', 'guardian123');
        localStorage.setItem('guardian_token', loginData.token);
        const data = await api.getMe();
        setUser(data.user);
        setHousehold(data.household);
      } catch (e) {
        console.error('Failed demo initialization:', e);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProfile();
  }, []);

  const login = async (email, password) => {
    const data = await api.login(email, password);
    localStorage.setItem('guardian_token', data.token);
    await loadProfile();
    return data;
  };

  const logout = () => {
    localStorage.removeItem('guardian_token');
    setUser(null);
    setHousehold(null);
  };

  return (
    <AuthContext.Provider value={{ user, household, setHousehold, loading, login, logout, refreshProfile: loadProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);

