import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';
import { useSocket } from './SocketContext';
import { useAuth } from './AuthContext';

const PrivacyContext = createContext(null);

export const PrivacyProvider = ({ children }) => {
  const { household, setHousehold } = useAuth();
  const { socket } = useSocket();
  const [privacyMode, setPrivacyMode] = useState(false);
  const [cameraHardwareActive, setCameraHardwareActive] = useState(false);
  const [micHardwareActive, setMicHardwareActive] = useState(false);

  useEffect(() => {
    if (household) {
      setPrivacyMode(!!household.privacyModeActive);
    }
  }, [household]);

  useEffect(() => {
    if (!socket) return;
    socket.on('privacy:toggled', ({ privacyModeActive }) => {
      setPrivacyMode(privacyModeActive);
      if (household) {
        setHousehold({ ...household, privacyModeActive });
      }
    });

    return () => {
      socket.off('privacy:toggled');
    };
  }, [socket, household]);

  const togglePrivacy = async () => {
    const nextState = !privacyMode;
    try {
      await api.togglePrivacyMode(nextState);
      setPrivacyMode(nextState);
      if (nextState) {
        setCameraHardwareActive(false);
        setMicHardwareActive(false);
      }
    } catch (err) {
      console.error('Failed to toggle privacy mode:', err);
    }
  };

  return (
    <PrivacyContext.Provider
      value={{
        privacyMode,
        togglePrivacy,
        cameraHardwareActive,
        setCameraHardwareActive,
        micHardwareActive,
        setMicHardwareActive
      }}
    >
      {children}
    </PrivacyContext.Provider>
  );
};

export const usePrivacy = () => useContext(PrivacyContext);

