import React, { useEffect, useState } from 'react';
import { ShieldAlert, HeartHandshake, CheckCircle2, PhoneCall, Volume2, Mic } from 'lucide-react';
import { useEmergency } from '../../context/EmergencyContext';

export const TriageDialogue = () => {
  const {
    activeEmergency,
    countdown,
    showTriageDialog,
    voiceChallengeText,
    confirmSafe,
    requestImmediateHelp
  } = useEmergency();

  const [spokenPrompt, setSpokenPrompt] = useState(false);
  const [listeningForAnswer, setListeningForAnswer] = useState(false);
  const [voiceInputRecognized, setVoiceInputRecognized] = useState('');

  // Audio Speech Synthesis when dialogue appears
  useEffect(() => {
    if (showTriageDialog && !spokenPrompt && 'speechSynthesis' in window) {
      try {
        const textToSpeak = voiceChallengeText || 'Are you alright? I detected a possible fall. Do you need medical assistance?';
        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        utterance.rate = 0.95;
        utterance.pitch = 1.0;
        window.speechSynthesis.speak(utterance);
        setSpokenPrompt(true);
      } catch (err) {
        console.warn('Speech synthesis unavailable:', err);
      }
    }
  }, [showTriageDialog, spokenPrompt, voiceChallengeText]);

  // Voice recognition for hands-free answer ("I'm fine" / "Help")
  const startVoiceListener = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Voice recognition is not supported in this browser. Please click the buttons below.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    setListeningForAnswer(true);

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript.toLowerCase();
      setVoiceInputRecognized(transcript);
      setListeningForAnswer(false);

      if (transcript.includes('fine') || transcript.includes('okay') || transcript.includes('theek') || transcript.includes('safe')) {
        confirmSafe(`User confirmed verbally: "${transcript}"`);
      } else if (transcript.includes('help') || transcript.includes('madad') || transcript.includes('doctor') || transcript.includes('pain')) {
        requestImmediateHelp(`User requested help verbally: "${transcript}"`);
      }
    };

    recognition.onerror = () => {
      setListeningForAnswer(false);
    };

    recognition.onend = () => {
      setListeningForAnswer(false);
    };

    recognition.start();
  };

  if (!showTriageDialog || !activeEmergency) return null;

  const progressPercent = Math.max(0, Math.min(100, (countdown / 30) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-xl glass-panel-warning rounded-2xl p-6 sm:p-8 border-2 border-amber-500/60 shadow-2xl relative overflow-hidden">
        
        {/* Urgent Pulsing Top Banner */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/30">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/50 animate-pulse">
              <ShieldAlert className="w-7 h-7" />
            </div>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-bold px-2 py-0.5 rounded bg-amber-950/80 border border-amber-500/30">
                LEVEL 2: WARNING PROTOCOL
              </span>
              <h2 className="text-xl font-extrabold text-white mt-1">Autonomous Verification In Progress</h2>
            </div>
          </div>

          {/* Countdown Clock */}
          <div className="text-right">
            <div className="text-2xl font-mono font-extrabold text-amber-400 animate-pulse">
              {countdown}s
            </div>
            <span className="text-[10px] uppercase font-mono text-slate-400">Escalation in</span>
          </div>
        </div>

        {/* Progress Countdown Bar */}
        <div className="w-full h-2 bg-slate-900 rounded-full mt-3 overflow-hidden border border-slate-800">
          <div
            className="h-full bg-gradient-to-r from-amber-500 to-red-500 transition-all duration-1000 ease-linear rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Voice Challenge Box */}
        <div className="my-6 p-4 rounded-xl bg-navy-900/90 border border-amber-500/30 flex items-start gap-3">
          <Volume2 className="w-6 h-6 text-cyan-400 shrink-0 mt-0.5 animate-pulse" />
          <div>
            <span className="text-xs font-mono uppercase text-cyan-300 font-bold">GuardianAI Voice Triage Prompt:</span>
            <p className="text-slate-100 font-medium text-base mt-1">
              "{voiceChallengeText || 'Are you alright? I detected a possible fall. Do you need medical assistance?'}"
            </p>
            <p className="text-xs text-slate-400 mt-2 font-mono">
              Auto-escalating to Emergency 112 & Primary Contacts if no response within {countdown}s.
            </p>
          </div>
        </div>

        {/* Voice Input Indicator */}
        {voiceInputRecognized && (
          <div className="mb-4 text-xs font-mono text-cyan-300 bg-cyan-950/60 p-2.5 rounded-lg border border-cyan-500/30">
            Heard: "{voiceInputRecognized}"
          </div>
        )}

        {/* Decision Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {/* Safe Confirmation Button */}
          <button
            onClick={() => confirmSafe('User tapped "I am Safe"')}
            className="flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-xl font-bold text-sm bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/60 transition-all hover:scale-[1.02] active:scale-98"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>I Am Safe (Dismiss)</span>
          </button>

          {/* Emergency Escalation Button */}
          <button
            onClick={() => requestImmediateHelp('User tapped "I Need Help"')}
            className="flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-xl font-bold text-sm bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white border border-red-500/60 shadow-lg shadow-red-950 transition-all hover:scale-[1.02] active:scale-98 animate-pulse"
          >
            <PhoneCall className="w-5 h-5 text-white" />
            <span>I Need Help! (Call 112)</span>
          </button>
        </div>

        {/* Hands-Free Voice Response Button */}
        <div className="mt-4 text-center">
          <button
            onClick={startVoiceListener}
            disabled={listeningForAnswer}
            className={`inline-flex items-center gap-2 text-xs font-mono py-2 px-4 rounded-lg border transition-all ${
              listeningForAnswer
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400 animate-pulse'
                : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-slate-500'
            }`}
          >
            <Mic className={`w-3.5 h-3.5 ${listeningForAnswer ? 'text-cyan-400 animate-spin' : 'text-slate-400'}`} />
            <span>{listeningForAnswer ? 'Listening for speech ("I am fine" / "Help")...' : 'Respond Hands-Free via Voice'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};

