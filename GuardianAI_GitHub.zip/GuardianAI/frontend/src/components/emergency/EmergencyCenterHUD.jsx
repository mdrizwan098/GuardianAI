import React, { useState } from 'react';
import {
  ShieldAlert,
  PhoneCall,
  UserCheck,
  Stethoscope,
  Radio,
  Clock,
  MapPin,
  FileText,
  AlertTriangle,
  Flame,
  Activity,
  DoorClosed,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { useEmergency } from '../../context/EmergencyContext';
import { api } from '../../services/api';

export const EmergencyCenterHUD = () => {
  const {
    activeEmergency,
    countdown,
    riskAssessment,
    dispatchResult,
    confirmSafe,
    requestImmediateHelp,
    triggerManualSOS,
    setDispatchResult
  } = useEmergency();

  const [loadingAction, setLoadingAction] = useState(false);
  const [doctorCallState, setDoctorCallState] = useState(null);

  const handleManual112 = async (serviceType = 'ALL', reason = 'Manual Operator Request') => {
    setLoadingAction(true);
    try {
      const res = await api.dispatch112(activeEmergency?._id, serviceType, reason);
      setDispatchResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAction(false);
    }
  };

  const handleConnectDoctor = async () => {
    setLoadingAction(true);
    try {
      const res = await api.connectDoctor(activeEmergency?._id);
      setDoctorCallState(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAction(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Active Threat / Normal Status Hero Card */}
      <div className={`rounded-2xl p-6 transition-all duration-300 border ${
        !activeEmergency
          ? 'glass-panel border-slate-800'
          : activeEmergency.riskClassification === 'LEVEL_3_CRITICAL'
          ? 'glass-panel-alert border-red-500/80'
          : 'glass-panel-warning border-amber-500/80'
      }`}>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className={`p-4 rounded-2xl ${
              !activeEmergency
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : activeEmergency.riskClassification === 'LEVEL_3_CRITICAL'
                ? 'bg-red-500/20 text-red-400 border border-red-500/60 animate-pulse'
                : 'bg-amber-500/20 text-amber-400 border border-amber-500/60 animate-pulse'
            }`}>
              {!activeEmergency ? (
                <CheckCircle2 className="w-8 h-8" />
              ) : (
                <ShieldAlert className="w-8 h-8" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className={`text-[11px] font-mono uppercase px-2 py-0.5 rounded font-bold ${
                  !activeEmergency
                    ? 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-300'
                    : activeEmergency.riskClassification === 'LEVEL_3_CRITICAL'
                    ? 'bg-red-950/90 border border-red-500/60 text-red-300 animate-pulse'
                    : 'bg-amber-950/90 border border-amber-500/60 text-amber-300'
                }`}>
                  {!activeEmergency ? 'SYSTEM NOMINAL' : activeEmergency.riskClassification}
                </span>

                {activeEmergency && (
                  <span className="text-xs font-mono text-slate-400">
                    ID: {activeEmergency.eventId}
                  </span>
                )}
              </div>

              <h2 className="text-2xl font-extrabold text-white mt-1">
                {!activeEmergency
                  ? 'All Household Sectors Secure & Monitored'
                  : activeEmergency.eventType.replace('_', ' ').toUpperCase()}
              </h2>

              <p className="text-xs text-slate-300 mt-1 max-w-xl">
                {!activeEmergency
                  ? 'MoveNet vision kinematics, acoustic distress classification, and door/smoke IoT telemetry running continuously.'
                  : riskAssessment?.aiReasoningSummary || 'Incident detected by multi-sensor correlation engine.'}
              </p>
            </div>
          </div>

          {/* Countdown & Quick Action */}
          {activeEmergency && (
            <div className="flex flex-col items-end gap-2">
              {countdown > 0 && (
                <div className="text-right">
                  <div className="text-3xl font-mono font-extrabold text-amber-400 animate-pulse">
                    {countdown}s
                  </div>
                  <span className="text-[10px] font-mono uppercase text-slate-400">
                    {activeEmergency.riskClassification === 'LEVEL_2_WARNING'
                      ? 'Verification Timeout'
                      : 'Abort Window Remaining'}
                  </span>
                </div>
              )}

              <div className="flex items-center gap-2 mt-1">
                <button
                  onClick={() => confirmSafe('Manual Stand Down clicked')}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
                >
                  Confirm Safe / Stand Down
                </button>

                <button
                  onClick={() => handleManual112('ALL', 'Direct manual 112 dispatch from Emergency Center')}
                  disabled={loadingAction}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white border border-red-500/60 shadow-lg shadow-red-950 transition-all animate-pulse"
                >
                  Dispatch 112 Immediately
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Emergency 112 Dispatch Dossier (When Dispatched) */}
      {dispatchResult && (
        <div className="glass-panel-alert rounded-2xl p-6 border border-red-500/60 animate-fade-in">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-red-500/30">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-red-600/30 text-red-300 border border-red-500/50">
                <Radio className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase bg-red-950 px-2 py-0.5 rounded border border-red-500/40 text-red-300 font-bold">
                  {dispatchResult.mode} • ERSS 112 DISPATCH ACKNOWLEDGED
                </span>
                <h3 className="text-lg font-bold text-white mt-0.5">Emergency Services En Route</h3>
              </div>
            </div>

            <div className="text-right">
              <span className="text-2xl font-mono font-extrabold text-red-400">
                ~{dispatchResult.etaMinutes} mins
              </span>
              <span className="text-[10px] uppercase font-mono text-slate-400 block">Estimated Arrival Time</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 text-xs font-mono">
            <div className="p-3 rounded-xl bg-navy-900/80 border border-slate-800">
              <span className="text-slate-400 uppercase text-[10px] block flex items-center gap-1.5 mb-1">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" /> Transmitted GPS & Address
              </span>
              <p className="text-slate-200 font-semibold">{dispatchResult.payload?.householdDetails?.address?.street}, {dispatchResult.payload?.householdDetails?.address?.city}</p>
              <p className="text-cyan-400 text-[11px] mt-1">
                Coord: [{dispatchResult.payload?.householdDetails?.address?.coordinates?.latitude}, {dispatchResult.payload?.householdDetails?.address?.coordinates?.longitude}]
              </p>
            </div>

            <div className="p-3 rounded-xl bg-navy-900/80 border border-slate-800">
              <span className="text-slate-400 uppercase text-[10px] block flex items-center gap-1.5 mb-1">
                <Activity className="w-3.5 h-3.5 text-red-400" /> Transmitted Medical Dossier
              </span>
              <ul className="text-slate-200 space-y-1">
                {dispatchResult.payload?.medicalAlerts?.map((m, idx) => (
                  <li key={idx} className="truncate">• {m}</li>
                )) || <li>• Medical records synced with dispatcher</li>}
              </ul>
            </div>

            <div className="p-3 rounded-xl bg-navy-900/80 border border-slate-800">
              <span className="text-slate-400 uppercase text-[10px] block flex items-center gap-1.5 mb-1">
                <FileText className="w-3.5 h-3.5 text-amber-400" /> Dispatch Audit Tracking
              </span>
              <p className="text-slate-300">Dispatch ID: <strong className="text-white">{dispatchResult.dispatchId}</strong></p>
              <p className="text-slate-300">Target Line: <strong className="text-emerald-400">{dispatchResult.targetNumber}</strong></p>
              <p className="text-emerald-400 font-bold mt-1">Status: {dispatchResult.status}</p>
            </div>
          </div>
        </div>
      )}

      {/* Doctor Call Status Dossier */}
      {doctorCallState && (
        <div className="glass-panel-cyan rounded-2xl p-5 border border-cyan-500/40 animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
                <Stethoscope className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase text-cyan-300 font-bold">PHYSICIAN TELECONSULT CONNECTED</span>
                <h4 className="text-base font-bold text-white">{doctorCallState.doctor?.name} ({doctorCallState.doctor?.relationship})</h4>
                <p className="text-xs text-slate-300 font-mono">Direct secure audio link active • {doctorCallState.doctor?.phone}</p>
              </div>
            </div>

            <button
              onClick={() => setDoctorCallState(null)}
              className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg border border-slate-800 hover:border-slate-700"
            >
              Close Consult Banner
            </button>
          </div>
        </div>
      )}

      {/* Emergency Shortcuts Grid */}
      <div>
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 font-mono">
          Manual Emergency Escalation Triggers
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Fall SOS */}
          <button
            onClick={() => triggerManualSOS('Manual Medical Fall Emergency Triggered')}
            className="glass-panel rounded-2xl p-5 border border-slate-800 hover:border-amber-500/60 text-left transition-all hover:scale-[1.02] active:scale-98 group"
          >
            <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 w-fit mb-3 group-hover:bg-amber-500/20 transition-all">
              <Activity className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-sm">Medical / Fall SOS</h4>
            <p className="text-xs text-slate-400 mt-1">
              Triggers Level 2 voice verification with 30s countdown to 112 ambulance dispatch.
            </p>
          </button>

          {/* Fire SOS */}
          <button
            onClick={() => handleManual112('FIRE', 'Manual Fire Alarm SOS Triggered')}
            className="glass-panel rounded-2xl p-5 border border-slate-800 hover:border-red-500/60 text-left transition-all hover:scale-[1.02] active:scale-98 group"
          >
            <div className="p-3 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 w-fit mb-3 group-hover:bg-red-500/20 transition-all">
              <Flame className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-sm">Fire & Smoke SOS</h4>
            <p className="text-xs text-slate-400 mt-1">
              Instant Level 3 Critical dispatch to Fire Brigade & emergency notifications.
            </p>
          </button>

          {/* Intruder / Breach SOS */}
          <button
            onClick={() => handleManual112('POLICE', 'Manual Forced Intrusion SOS Triggered')}
            className="glass-panel rounded-2xl p-5 border border-slate-800 hover:border-cyan-500/60 text-left transition-all hover:scale-[1.02] active:scale-98 group"
          >
            <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 w-fit mb-3 group-hover:bg-cyan-500/20 transition-all">
              <DoorClosed className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-sm">Intruder & Breach SOS</h4>
            <p className="text-xs text-slate-400 mt-1">
              Alerts Police 112, activates surveillance lock, and notifies primary contact.
            </p>
          </button>

          {/* Call Doctor Direct */}
          <button
            onClick={handleConnectDoctor}
            className="glass-panel rounded-2xl p-5 border border-slate-800 hover:border-blue-500/60 text-left transition-all hover:scale-[1.02] active:scale-98 group"
          >
            <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 w-fit mb-3 group-hover:bg-blue-500/20 transition-all">
              <Stethoscope className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-sm">Call Registered Doctor</h4>
            <p className="text-xs text-slate-400 mt-1">
              Connects directly to Dr. Rajesh Gupta (Cardiologist) with medical context.
            </p>
          </button>

        </div>
      </div>

    </div>
  );
};

