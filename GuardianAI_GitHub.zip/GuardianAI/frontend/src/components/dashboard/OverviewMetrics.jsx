import React, { useState, useEffect } from 'react';
import {
  Shield,
  Activity,
  Users,
  Video,
  Radio,
  AlertTriangle,
  CheckCircle2,
  PhoneCall,
  Clock,
  ArrowRight,
  Flame,
  DoorOpen,
  Sparkles
} from 'lucide-react';
import { useEmergency } from '../../context/EmergencyContext';
import { useAuth } from '../../context/AuthContext';
import { usePrivacy } from '../../context/PrivacyContext';
import { api } from '../../services/api';

export const OverviewMetrics = ({ setActiveTab }) => {
  const { household } = useAuth();
  const { activeEmergency, triggerManualSOS } = useEmergency();
  const { privacyMode } = usePrivacy();

  const [devices, setDevices] = useState([]);
  const [familyMembers, setFamilyMembers] = useState([]);
  const [recentEvents, setRecentEvents] = useState([]);

  useEffect(() => {
    const loadOverview = async () => {
      try {
        const [devs, fam, evts] = await Promise.all([
          api.getDevices(),
          api.getFamilyMembers(),
          api.getRecentEvents()
        ]);
        setDevices(devs);
        setFamilyMembers(fam);
        setRecentEvents(evts);
      } catch (err) {
        console.warn('Overview load error:', err);
      }
    };
    loadOverview();
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Metric 1: System Sentry */}
        <div className="glass-panel rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-slate-400">Autonomous Sentry</span>
            <span className={`w-2 h-2 rounded-full ${
              activeEmergency ? 'bg-red-500 animate-ping' : privacyMode ? 'bg-amber-400' : 'bg-emerald-400'
            }`} />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className={`text-2xl font-extrabold ${
              activeEmergency ? 'text-red-400' : privacyMode ? 'text-amber-300' : 'text-emerald-400'
            }`}>
              {activeEmergency ? 'ALERT ACTIVE' : privacyMode ? 'PRIVACY MODE' : 'ARMED & ACTIVE'}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">
            {household?.name || 'Home Security Center'}
          </p>
        </div>

        {/* Metric 2: Connected Peripherals */}
        <div className="glass-panel rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-slate-400">Connected Peripherals</span>
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{devices.length || 5} Devices</span>
            <span className="text-xs font-mono text-emerald-400">100% ONLINE</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">
            Cameras, PIR, Smoke & Glass Sensors
          </p>
        </div>

        {/* Metric 3: Family Members Home */}
        <div className="glass-panel rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-slate-400">Household Presence</span>
            <Users className="w-4 h-4 text-electric-400" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">
              {familyMembers.filter(m => m.availabilityStatus === 'home').length} at Home
            </span>
            <span className="text-xs font-mono text-slate-400">/ {familyMembers.length} Registered</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">
            Kailash (74y) in Living Room
          </p>
        </div>

        {/* Metric 4: Emergency 112 Gateway */}
        <div className="glass-panel rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-slate-400">ERSS 112 Gateway</span>
            <PhoneCall className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-cyan-300">National 112</span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/40">READY</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">
            Direct dispatch & medical dossier sync
          </p>
        </div>

      </div>

      {/* Main Split: Camera Quick Look & Real-Time Incident Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Live Feed Spotlight */}
        <div className="lg:col-span-2 glass-panel rounded-2xl p-5 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
                  <Video className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Primary Optical Feed Spotlight</h3>
                  <p className="text-xs text-slate-400 font-mono">Living Room View • MoveNet Posture Analyzer</p>
                </div>
              </div>

              <button
                onClick={() => setActiveTab('monitoring')}
                className="flex items-center gap-1.5 text-xs font-mono text-cyan-400 hover:text-cyan-300 transition-all"
              >
                <span>Full CV Console</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Preview Box */}
            <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-navy-950 border border-slate-800 flex items-center justify-center scanline">
              <div className="text-center p-6">
                <Activity className="w-10 h-10 text-cyan-400 mx-auto mb-2 animate-pulse" />
                <h4 className="font-bold text-white text-sm">Computer Vision Fall Kinematics Active</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                  Monitoring centroid vertical descent velocity, bounding box aspect ratio, and floor dwell duration.
                </p>
              </div>

              <div className="absolute bottom-3 left-3 text-[10px] font-mono text-cyan-300 bg-navy-900/80 px-2 py-1 rounded border border-cyan-500/30">
                LIVING ROOM CAM • 1080P 60FPS
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Calibrated Safe Room: <strong className="text-white">{household?.safeRoomLocation || 'Master Bedroom'}</strong></span>
            <button
              onClick={() => setActiveTab('monitoring')}
              className="text-cyan-400 hover:underline"
            >
              Open Full Kinematics & Audio Spectrum &rarr;
            </button>
          </div>
        </div>

        {/* Right Col: Recent Sensor Activity Stream */}
        <div className="glass-panel rounded-2xl p-5 border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                <span>Recent Sensor Stream</span>
              </h3>
              <span className="text-[10px] font-mono text-slate-500 uppercase">Live Telemetry</span>
            </div>

            <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
              {recentEvents.length > 0 ? (
                recentEvents.slice(0, 6).map((evt) => (
                  <div key={evt._id} className="p-3 rounded-xl bg-navy-900/60 border border-slate-800/80 text-xs">
                    <div className="flex items-center justify-between">
                      <span className={`font-bold uppercase font-mono text-[10px] ${
                        evt.eventType.includes('fall') || evt.eventType.includes('smoke') || evt.eventType.includes('forced')
                          ? 'text-red-400'
                          : 'text-cyan-400'
                      }`}>
                        {evt.eventType.replace('_', ' ')}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500">
                        {new Date(evt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-slate-300 text-[11px] mt-1 truncate">
                      Confidence: {Math.round((evt.rawConfidence || 0.85) * 100)}% • {evt.telemetryData?.zone || 'Household perimeter'}
                    </p>
                  </div>
                ))
              ) : (
                <div className="text-center py-12 text-slate-500 text-xs font-mono">
                  No critical incidents detected. System standing by.
                </div>
              )}
            </div>
          </div>

          <button
            onClick={() => setActiveTab('iot_audit')}
            className="w-full mt-4 py-2 rounded-xl text-xs font-mono text-center bg-slate-900 text-slate-300 hover:text-white border border-slate-800"
          >
            View Complete Audit Log &rarr;
          </button>
        </div>

      </div>

    </div>
  );
};

