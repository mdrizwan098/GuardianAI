import React, { useState, useEffect } from 'react';
import { Users, Video, Phone, ShieldCheck, HeartPulse, Plus, Check, Clock } from 'lucide-react';
import { api } from '../../services/api';
import { WebRTCVideoRoom } from './WebRTCVideoRoom';

export const FamilyMemberDirectory = () => {
  const [familyMembers, setFamilyMembers] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [activeVideoTarget, setActiveVideoTarget] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      const [membersData, contactsData] = await Promise.all([
        api.getFamilyMembers(),
        api.getContacts()
      ]);
      setFamilyMembers(membersData);
      setContacts(contactsData);
    } catch (err) {
      console.error('Failed to load family data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleStatusChange = async (memberId, newStatus) => {
    try {
      await api.updateMemberStatus(memberId, newStatus);
      setFamilyMembers(familyMembers.map(m => m._id === memberId ? { ...m, availabilityStatus: newStatus } : m));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-8">
      
      {/* Active WebRTC Video Modal */}
      {activeVideoTarget && (
        <WebRTCVideoRoom
          targetMember={activeVideoTarget}
          onClose={() => setActiveVideoTarget(null)}
        />
      )}

      {/* Family Members Header */}
      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Users className="w-6 h-6 text-cyan-400" />
              <span>Authorized Family Network</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Real-time member presence, medical profiles, and peer-to-peer WebRTC video communication.
            </p>
          </div>
        </div>

        {/* Family Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {familyMembers.map((member) => (
            <div
              key={member._id}
              className="glass-panel rounded-2xl p-5 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="relative">
                    <img
                      src={member.avatarUrl}
                      alt={member.fullName}
                      className="w-14 h-14 rounded-2xl object-cover ring-2 ring-slate-700"
                    />
                    <span className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-navy-950 ${
                      member.availabilityStatus === 'home'
                        ? 'bg-emerald-500'
                        : member.availabilityStatus === 'away'
                        ? 'bg-amber-500'
                        : 'bg-slate-500'
                    }`} />
                  </div>

                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    P{member.emergencyPriority} CONTACT
                  </span>
                </div>

                <div className="mt-3">
                  <h3 className="font-bold text-white text-base">{member.fullName}</h3>
                  <p className="text-xs text-cyan-400 font-mono capitalize">
                    {member.relationship} • {member.age} years old
                  </p>
                </div>

                {/* Medical Conditions Badges */}
                {member.medicalConditions && member.medicalConditions.length > 0 && member.medicalConditions[0] !== 'None' && (
                  <div className="mt-3 p-2 rounded-xl bg-red-950/40 border border-red-500/30">
                    <span className="text-[10px] uppercase font-mono text-red-400 font-bold flex items-center gap-1">
                      <HeartPulse className="w-3 h-3" /> Medical Alert
                    </span>
                    <p className="text-xs text-slate-200 mt-0.5 font-medium">
                      {member.medicalConditions.join(', ')}
                    </p>
                  </div>
                )}

                {/* Status Toggle Buttons */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-1.5">
                  <span className="text-[10px] font-mono text-slate-500 uppercase mr-1">Status:</span>
                  {['home', 'away', 'busy'].map((s) => (
                    <button
                      key={s}
                      onClick={() => handleStatusChange(member._id, s)}
                      className={`text-[10px] uppercase font-mono px-2 py-1 rounded transition-all ${
                        member.availabilityStatus === s
                          ? s === 'home'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                            : s === 'away'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                            : 'bg-blue-500/20 text-blue-300 border border-blue-500/40 font-bold'
                          : 'bg-slate-900 text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Start WebRTC Call Button */}
              <div className="mt-5">
                <button
                  onClick={() => setActiveVideoTarget(member)}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl font-bold text-xs bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 transition-all hover:scale-[1.02] active:scale-98"
                >
                  <Video className="w-4 h-4 text-cyan-400" />
                  <span>Connect Live Video</span>
                </button>
              </div>

            </div>
          ))}
        </div>
      </div>

      {/* Emergency Contacts Priority Chain */}
      <div>
        <div className="flex items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Phone className="w-5 h-5 text-amber-400" />
              <span>Emergency Escalation Contact Chain</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Strict deterministic notification hierarchy triggered when user is unresponsive.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {contacts.map((contact) => (
            <div
              key={contact._id}
              className="glass-panel rounded-2xl p-4 border border-slate-800"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono uppercase bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/40 font-bold">
                  Priority {contact.priorityOrder}
                </span>
                <span className="text-[10px] font-mono text-slate-500 uppercase">{contact.contactType}</span>
              </div>

              <h4 className="font-bold text-white text-sm">{contact.name}</h4>
              <p className="text-xs text-slate-400 font-mono mt-0.5">{contact.phone}</p>
              <p className="text-[11px] text-slate-500 mt-1">{contact.relationship}</p>

              <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span>SMS: {contact.notifyViaSms ? '✓ Authorized' : '✗ Disabled'}</span>
                <span>Voice: {contact.notifyViaCall ? '✓ Authorized' : '✗ Disabled'}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};

