import React, { useRef, useState, useEffect } from 'react';
import { Camera, EyeOff, Activity, ShieldAlert, Play, Square, RefreshCw, Zap } from 'lucide-react';
import { api } from '../../services/api';
import { usePrivacy } from '../../context/PrivacyContext';

export const VisionFallDetector = () => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const { privacyMode, setCameraHardwareActive } = usePrivacy();

  const [useRealWebcam, setUseRealWebcam] = useState(false);
  const [streamActive, setStreamActive] = useState(false);
  const [kinematicState, setKinematicState] = useState('NORMAL_STANDING'); // 'NORMAL_STANDING' | 'SUDDEN_DESCENT' | 'FALL_DETECTED' | 'MOTIONLESS_DWELL'
  const [aspectRatio, setAspectRatio] = useState(0.48); // W/H ratio (standing < 0.8, fall > 1.3)
  const [velocity, setVelocity] = useState(0.08); // m/s
  const [dwellSeconds, setDwellSeconds] = useState(0);
  const [simulatingFall, setSimulatingFall] = useState(false);

  // Handle Real Webcam Stream
  useEffect(() => {
    let currentStream = null;

    if (useRealWebcam && !privacyMode) {
      navigator.mediaDevices?.getUserMedia({ video: { width: 640, height: 480 }, audio: false })
        .then((stream) => {
          currentStream = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play();
          }
          setStreamActive(true);
          setCameraHardwareActive(true);
        })
        .catch((err) => {
          console.warn('Real webcam unavailable or denied, falling back to synthetic stream:', err.message);
          setUseRealWebcam(false);
        });
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(t => t.stop());
        videoRef.current.srcObject = null;
      }
      setStreamActive(false);
      setCameraHardwareActive(false);
    }

    return () => {
      if (currentStream) {
        currentStream.getTracks().forEach(t => t.stop());
      }
      setCameraHardwareActive(false);
    };
  }, [useRealWebcam, privacyMode]);

  // Synthetic Canvas Animation & Kinematic Computer Vision Simulator Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;

    let posY = 120;
    let targetY = 120;
    let boxWidth = 90;
    let boxHeight = 190;
    let velocityY = 0;
    let floorDwellTimer = 0;

    const renderLoop = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (privacyMode) {
        // Privacy mode active - optical blindness
        ctx.fillStyle = '#060A12';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        animId = requestAnimationFrame(renderLoop);
        return;
      }

      // Draw background synthetic living room grid
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.15)';
      ctx.lineWidth = 1;
      for (let x = 0; x < canvas.width; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Draw floor plane line
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.5)';
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.moveTo(0, 360);
      ctx.lineTo(canvas.width, 360);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(6, 182, 212, 0.6)';
      ctx.font = '10px monospace';
      ctx.fillText('CALIBRATED FLOOR PLANE [Z: 0.0m]', 15, 350);

      // Kinematic update
      if (simulatingFall) {
        targetY = 320;
        boxWidth = 210;
        boxHeight = 65;
        velocityY = (targetY - posY) * 0.12;
        posY += velocityY;
        
        if (Math.abs(targetY - posY) < 4) {
          floorDwellTimer += 0.03;
          setDwellSeconds(Math.floor(floorDwellTimer));
          if (floorDwellTimer > 2.5) {
            setKinematicState('MOTIONLESS_DWELL');
          } else {
            setKinematicState('FALL_DETECTED');
          }
        } else {
          setKinematicState('SUDDEN_DESCENT');
        }
      } else {
        targetY = 120;
        boxWidth = 90;
        boxHeight = 190;
        posY += (targetY - posY) * 0.1;
        floorDwellTimer = 0;
        setDwellSeconds(0);
        setKinematicState('NORMAL_STANDING');
      }

      const ratio = Number((boxWidth / boxHeight).toFixed(2));
      setAspectRatio(ratio);
      setVelocity(Number(Math.abs(velocityY).toFixed(2)));

      // Draw bounding box
      const boxX = (canvas.width - boxWidth) / 2;
      let strokeColor = '#10B981'; // Green
      let fillColor = 'rgba(16, 185, 129, 0.15)';

      if (kinematicState === 'SUDDEN_DESCENT') {
        strokeColor = '#F59E0B'; // Amber
        fillColor = 'rgba(245, 158, 11, 0.2)';
      } else if (kinematicState === 'FALL_DETECTED' || kinematicState === 'MOTIONLESS_DWELL') {
        strokeColor = '#EF4444'; // Red
        fillColor = 'rgba(239, 68, 68, 0.25)';
      }

      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 2.5;
      ctx.fillStyle = fillColor;
      ctx.strokeRect(boxX, posY, boxWidth, boxHeight);
      ctx.fillRect(boxX, posY, boxWidth, boxHeight);

      // Centroid marker
      const centerX = boxX + boxWidth / 2;
      const centerY = posY + boxHeight / 2;
      ctx.fillStyle = strokeColor;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 5, 0, Math.PI * 2);
      ctx.fill();

      // Velocity kinematic vector
      if (Math.abs(velocityY) > 0.5) {
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(centerX, centerY + velocityY * 4);
        ctx.strokeStyle = '#EF4444';
        ctx.lineWidth = 3;
        ctx.stroke();
      }

      // Kinematic text labels
      ctx.fillStyle = strokeColor;
      ctx.font = '11px monospace';
      ctx.fillText(`SUBJECT: Kailash Sharma (74y)`, boxX, posY - 24);
      ctx.fillText(`ASPECT RATIO (W/H): ${ratio} | V_y: ${Math.abs(velocityY).toFixed(1)}m/s`, boxX, posY - 10);

      animId = requestAnimationFrame(renderLoop);
    };

    animId = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(animId);
  }, [privacyMode, simulatingFall, kinematicState]);

  // Trigger Backend Emergency Event when Fall Reaches Threshold
  const handleTriggerSimulatedFall = async () => {
    setSimulatingFall(true);
    try {
      await api.triggerDetectionEvent({
        deviceId: 'dev_cam_01',
        eventType: 'fall_detected',
        rawConfidence: 0.94,
        telemetryData: {
          aspectRatio: 3.2,
          descentVelocity: '1.8m/s',
          motionlessDwellSeconds: 10,
          detectedZone: 'Living Room Floor'
        }
      });
    } catch (err) {
      console.error('Failed to trigger fall detection API:', err);
    }
  };

  const handleResetFall = () => {
    setSimulatingFall(false);
  };

  return (
    <div className="glass-panel rounded-2xl p-5 border border-slate-800">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Camera className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">Living Room Optical Stream & Fall Kinematics</h3>
            <p className="text-xs text-slate-400 font-mono">MoveNet Edge Kinematics • 1080p 60fps • Privacy Protected</p>
          </div>
        </div>

        {/* Toggle Real Webcam vs Synthetic Feed */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setUseRealWebcam(!useRealWebcam)}
            disabled={privacyMode}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition-all ${
              useRealWebcam
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                : 'bg-navy-900 text-slate-400 border-slate-700 hover:text-white'
            }`}
          >
            {useRealWebcam ? 'Source: Real Webcam' : 'Source: Synthetic Telemetry Feed'}
          </button>
        </div>
      </div>

      {/* Main Video / Canvas Feed Container */}
      <div className="relative aspect-[16/10] w-full bg-navy-950 rounded-xl overflow-hidden border border-slate-800/80 scanline">
        
        {/* Real Webcam Video (hidden behind canvas or active) */}
        <video
          ref={videoRef}
          playsInline
          muted
          className={`absolute inset-0 w-full h-full object-cover ${useRealWebcam && !privacyMode ? 'opacity-40' : 'hidden'}`}
        />

        {/* Kinematic Analysis Canvas */}
        <canvas
          ref={canvasRef}
          width={640}
          height={400}
          className="absolute inset-0 w-full h-full object-contain pointer-events-none"
        />

        {/* Privacy Mode Overlay */}
        {privacyMode && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center p-6 bg-navy-950/95 text-center">
            <div className="p-4 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/30 mb-3 animate-pulse">
              <EyeOff className="w-10 h-10" />
            </div>
            <h4 className="text-base font-bold text-white">OPTICAL SURVEILLANCE BLINDED</h4>
            <p className="text-xs text-slate-400 max-w-sm mt-1">
              Privacy Mode is active. Video stream, keypoints, and frame buffers are cryptographically disabled in hardware.
            </p>
          </div>
        )}

        {/* Top HUD Metrics Bar */}
        {!privacyMode && (
          <div className="absolute top-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none">
            <div className="flex items-center gap-2">
              <span className={`px-2 py-1 rounded text-[10px] font-mono font-bold tracking-wider uppercase ${
                kinematicState === 'NORMAL_STANDING'
                  ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40'
                  : kinematicState === 'SUDDEN_DESCENT'
                  ? 'bg-amber-950/80 text-amber-300 border border-amber-500/40 animate-pulse'
                  : 'bg-red-950/80 text-red-300 border border-red-500/40 animate-pulse'
              }`}>
                STATUS: {kinematicState.replace('_', ' ')}
              </span>
              <span className="text-[10px] font-mono text-cyan-400 bg-navy-900/80 px-2 py-1 rounded border border-slate-800">
                RATIO: {aspectRatio}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-slate-300 bg-navy-900/80 px-2 py-1 rounded border border-slate-800 flex items-center gap-1.5">
                <Activity className="w-3 h-3 text-cyan-400" />
                V: {velocity} m/s
              </span>
              {dwellSeconds > 0 && (
                <span className="text-[10px] font-mono text-red-400 bg-red-950/80 px-2 py-1 rounded border border-red-500/40 font-bold">
                  FLOOR DWELL: {dwellSeconds}s
                </span>
              )}
            </div>
          </div>
        )}

      </div>

      {/* Simulator Test Controls Bar */}
      <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-cyan-400" />
          <span className="text-xs text-slate-300 font-medium">Kinematic Event Trigger:</span>
        </div>

        <div className="flex items-center gap-2">
          {!simulatingFall ? (
            <button
              onClick={handleTriggerSimulatedFall}
              disabled={privacyMode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 transition-all hover:scale-105 active:scale-95 disabled:opacity-40"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Simulate Sudden Fall Kinematics</span>
            </button>
          ) : (
            <button
              onClick={handleResetFall}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset to Standing Posture</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

