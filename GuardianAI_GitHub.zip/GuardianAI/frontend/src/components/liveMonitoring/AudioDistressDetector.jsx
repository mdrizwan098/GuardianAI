import React, { useRef, useState, useEffect } from 'react';
import { Mic, MicOff, Volume2, ShieldAlert, Sparkles, BellRing } from 'lucide-react';
import { api } from '../../services/api';
import { usePrivacy } from '../../context/PrivacyContext';

export const AudioDistressDetector = () => {
  const { privacyMode, setMicHardwareActive } = usePrivacy();
  const canvasRef = useRef(null);

  const [useRealMic, setUseRealMic] = useState(false);
  const [audioLevel, setAudioLevel] = useState(12); // dB
  const [detectedAcousticPattern, setDetectedAcousticPattern] = useState('AMBIENT_NORMAL');
  const [spectralPeak, setSpectralPeak] = useState('240 Hz (Speech)');

  // Handle Real Microphone Web Audio API
  useEffect(() => {
    let audioCtx = null;
    let analyser = null;
    let stream = null;
    let animId = null;

    if (useRealMic && !privacyMode) {
      navigator.mediaDevices?.getUserMedia({ audio: true, video: false })
        .then((s) => {
          stream = s;
          audioCtx = new (window.AudioContext || window.webkitAudioContext)();
          analyser = audioCtx.createAnalyser();
          analyser.fftSize = 64;
          const source = audioCtx.createMediaStreamSource(stream);
          source.connect(analyser);

          setMicHardwareActive(true);

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          const draw = () => {
            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
              sum += dataArray[i];
            }
            const avg = sum / dataArray.length;
            const dbVal = Math.floor(avg * 0.8);
            setAudioLevel(dbVal);

            // Simple pattern check
            if (dbVal > 70) {
              setDetectedAcousticPattern('LOUD_DISTRESS_SPIKE');
            } else {
              setDetectedAcousticPattern('AMBIENT_NORMAL');
            }

            animId = requestAnimationFrame(draw);
          };
          draw();
        })
        .catch((err) => {
          console.warn('Real mic unavailable or denied:', err.message);
          setUseRealMic(false);
        });
    } else {
      setMicHardwareActive(false);
    }

    return () => {
      if (animId) cancelAnimationFrame(animId);
      if (stream) stream.getTracks().forEach(t => t.stop());
      if (audioCtx) audioCtx.close();
      setMicHardwareActive(false);
    };
  }, [useRealMic, privacyMode]);

  // Synthetic Spectrum Visualizer Canvas Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;

    const bars = 28;
    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (privacyMode) {
        ctx.fillStyle = '#060A12';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        animId = requestAnimationFrame(render);
        return;
      }

      const barWidth = (canvas.width / bars) - 2;

      for (let i = 0; i < bars; i++) {
        let height = 0;
        if (detectedAcousticPattern === 'GLASS_BREAK_TRANSIENT') {
          height = i > 18 ? Math.random() * 85 + 20 : Math.random() * 20;
        } else if (detectedAcousticPattern === 'SMOKE_ALARM_3KHZ') {
          height = (i >= 12 && i <= 15) ? 90 + Math.random() * 10 : Math.random() * 15;
        } else {
          // Normal ambient fluctuating wave
          height = Math.max(6, Math.sin(Date.now() * 0.005 + i * 0.4) * 20 + Math.random() * 15 + 10);
        }

        const x = i * (barWidth + 2);
        const y = canvas.height - height;

        let grad = ctx.createLinearGradient(0, canvas.height, 0, 0);
        if (detectedAcousticPattern === 'SMOKE_ALARM_3KHZ' || detectedAcousticPattern === 'GLASS_BREAK_TRANSIENT') {
          grad.addColorStop(0, '#EF4444');
          grad.addColorStop(1, '#F59E0B');
        } else {
          grad.addColorStop(0, '#06B6D4');
          grad.addColorStop(1, '#3B82F6');
        }

        ctx.fillStyle = grad;
        ctx.fillRect(x, y, barWidth, height);
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [privacyMode, detectedAcousticPattern]);

  const triggerSimulatedGlassBreak = async () => {
    setDetectedAcousticPattern('GLASS_BREAK_TRANSIENT');
    setSpectralPeak('4,850 Hz (Sharp Acoustic Impact)');
    setAudioLevel(86);
    try {
      await api.triggerDetectionEvent({
        deviceId: 'dev_sensor_03',
        eventType: 'glass_break',
        rawConfidence: 0.91,
        telemetryData: {
          frequency: '4.85kHz',
          peakDecibels: 86,
          zone: 'Balcony Glass Door'
        }
      });
      setTimeout(() => {
        setDetectedAcousticPattern('AMBIENT_NORMAL');
        setSpectralPeak('240 Hz (Speech)');
        setAudioLevel(16);
      }, 4000);
    } catch (err) {
      console.error(err);
    }
  };

  const triggerSimulatedFireAlarm = async () => {
    setDetectedAcousticPattern('SMOKE_ALARM_3KHZ');
    setSpectralPeak('3,120 Hz (ISO Smoke Alarm T3 Pulse)');
    setAudioLevel(94);
    try {
      await api.triggerDetectionEvent({
        deviceId: 'dev_sensor_02',
        eventType: 'smoke_detected',
        rawConfidence: 0.98,
        telemetryData: {
          frequency: '3.12kHz',
          peakDecibels: 94,
          zone: 'Kitchen Ceiling'
        }
      });
      setTimeout(() => {
        setDetectedAcousticPattern('AMBIENT_NORMAL');
        setSpectralPeak('240 Hz (Speech)');
        setAudioLevel(18);
      }, 5000);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="glass-panel rounded-2xl p-5 border border-slate-800">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <Volume2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">Acoustic Distress & Spectral Classifier</h3>
            <p className="text-xs text-slate-400 font-mono">FFT Audio Decomposition • 3kHz Alarm Spotter • Keyword Sensor</p>
          </div>
        </div>

        <button
          onClick={() => setUseRealMic(!useRealMic)}
          disabled={privacyMode}
          className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition-all ${
            useRealMic
              ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
              : 'bg-navy-900 text-slate-400 border-slate-700 hover:text-white'
          }`}
        >
          {useRealMic ? 'Mic: Real Hardware' : 'Mic: Synthetic Stream'}
        </button>
      </div>

      {/* Visualizer Canvas */}
      <div className="relative h-28 w-full bg-navy-950 rounded-xl overflow-hidden border border-slate-800/80 p-2">
        <canvas
          ref={canvasRef}
          width={450}
          height={110}
          className="w-full h-full object-cover"
        />

        {privacyMode && (
          <div className="absolute inset-0 flex items-center justify-center bg-navy-950/95 text-center p-3">
            <MicOff className="w-5 h-5 text-amber-400 mr-2" />
            <span className="text-xs font-mono text-amber-300">MIC ARRAY MUTED IN HARDWARE</span>
          </div>
        )}
      </div>

      {/* Metrics Row */}
      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        <div className="p-2 rounded-lg bg-navy-900/60 border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Volume Level</span>
          <span className="text-xs font-mono font-bold text-cyan-400">{audioLevel} dB</span>
        </div>
        <div className="p-2 rounded-lg bg-navy-900/60 border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Spectral Peak</span>
          <span className="text-xs font-mono font-bold text-slate-200 truncate block">{spectralPeak}</span>
        </div>
        <div className="p-2 rounded-lg bg-navy-900/60 border border-slate-800">
          <span className="text-[10px] text-slate-400 uppercase font-mono block">Acoustic State</span>
          <span className={`text-xs font-mono font-bold truncate block ${
            detectedAcousticPattern === 'AMBIENT_NORMAL' ? 'text-emerald-400' : 'text-red-400 animate-pulse'
          }`}>
            {detectedAcousticPattern}
          </span>
        </div>
      </div>

      {/* Acoustic Action Buttons */}
      <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-wrap gap-2 justify-end">
        <button
          onClick={triggerSimulatedGlassBreak}
          disabled={privacyMode}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all hover:scale-105 active:scale-95 disabled:opacity-40"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Simulate Glass Break Pulse</span>
        </button>

        <button
          onClick={triggerSimulatedFireAlarm}
          disabled={privacyMode}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 transition-all hover:scale-105 active:scale-95 disabled:opacity-40"
        >
          <BellRing className="w-3.5 h-3.5 text-red-400" />
          <span>Simulate 3kHz Fire Alarm</span>
        </button>
      </div>
    </div>
  );
};

