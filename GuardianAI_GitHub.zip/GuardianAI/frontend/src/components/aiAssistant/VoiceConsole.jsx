import React, { useState, useEffect, useRef } from 'react';
import { Bot, Mic, MicOff, Send, Volume2, Sparkles, User, Globe, AlertCircle, RefreshCw } from 'lucide-react';
import { api } from '../../services/api';
import { useEmergency } from '../../context/EmergencyContext';

export const VoiceConsole = () => {
  const { refreshEmergency } = useEmergency();
  const [messages, setMessages] = useState([
    {
      sender: 'ai',
      text: "Hello, I am GuardianAI, your household's intelligent safety companion. I am actively monitoring your home. How can I assist you right now?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [language, setLanguage] = useState('en'); // 'en' | 'hi' | 'hinglish'
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [suggestedPrompts, setSuggestedPrompts] = useState([]);
  const [loading, setLoading] = useState(false);

  const messagesEndRef = useRef(null);

  const loadPrompts = async (lang) => {
    try {
      const data = await api.getPrompts(lang);
      setSuggestedPrompts(data.suggestedPrompts || []);
    } catch (err) {
      console.warn('Failed to load prompts:', err);
    }
  };

  useEffect(() => {
    loadPrompts(language);
  }, [language]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Calm Voice Speech Synthesis
  const speakResponse = (text) => {
    if (!('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      if (language === 'hi') {
        utterance.lang = 'hi-IN';
      } else {
        utterance.lang = 'en-US';
      }

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn('Speech synthesis error:', err);
    }
  };

  // Speech Recognition (Mic to Text)
  const toggleSpeechRecognition = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser. Please type your message below.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = language === 'hi' ? 'hi-IN' : 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setInputText(transcript);
      handleSendMessage(transcript);
    };

    recognition.start();
  };

  const handleSendMessage = async (customText = null) => {
    const textToSend = customText || inputText;
    if (!textToSend.trim()) return;

    const userMsg = {
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    try {
      const res = await api.submitAITriage(textToSend, language);
      const aiMsg = {
        sender: 'ai',
        text: res.message,
        urgencyLevel: res.urgencyLevel,
        actionTriggered: res.actionTriggered,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, aiMsg]);
      speakResponse(res.message);

      if (res.actionTriggered) {
        refreshEmergency();
      }
    } catch (err) {
      console.error('AI Triage request failed:', err);
      setMessages(prev => [
        ...prev,
        {
          sender: 'ai',
          text: "I am having difficulty connecting, but our offline local emergency rules remain fully active to protect you.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="glass-panel rounded-2xl border border-slate-800 flex flex-col h-[700px] overflow-hidden">
      
      {/* Console Header */}
      <div className="p-4 px-6 border-b border-slate-800 bg-navy-900/80 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
            <Bot className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-white text-base">Multilingual AI Voice Assistant</h3>
              <span className="text-[10px] font-mono uppercase bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/40">
                CLINICAL TRIAGE READY
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Calm Emergency Responder • English / हिन्दी / Hinglish Support
            </p>
          </div>
        </div>

        {/* Language Selection */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-navy-950 border border-slate-800 text-xs font-mono">
          <Globe className="w-3.5 h-3.5 text-cyan-400 ml-1.5" />
          {[
            { id: 'en', label: 'English' },
            { id: 'hi', label: 'हिन्दी' },
            { id: 'hinglish', label: 'Hinglish' }
          ].map((lang) => (
            <button
              key={lang.id}
              onClick={() => setLanguage(lang.id)}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                language === lang.id
                  ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang.label}
            </button>
          ))}
        </div>
      </div>

      {/* Suggested Emergency Prompts Bar */}
      <div className="p-3 px-6 bg-navy-950/60 border-b border-slate-800/80 overflow-x-auto flex items-center gap-2">
        <span className="text-[11px] font-mono text-slate-500 uppercase shrink-0">Quick Commands:</span>
        {suggestedPrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(p.text)}
            className="text-xs font-medium px-3 py-1 rounded-lg bg-navy-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-cyan-500/40 whitespace-nowrap transition-all"
          >
            {p.text}
          </button>
        ))}
      </div>

      {/* Dialogue Stream Container */}
      <div className="flex-1 p-6 overflow-y-auto space-y-4">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex items-start gap-3 max-w-2xl ${
              msg.sender === 'user' ? 'ml-auto flex-row-reverse' : ''
            }`}
          >
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
              msg.sender === 'user'
                ? 'bg-electric-600/30 text-electric-300 border border-electric-500/40'
                : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
            }`}>
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div>
              <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-electric-600/20 border border-electric-500/30 text-white rounded-tr-none'
                  : msg.urgencyLevel === 'CRITICAL'
                  ? 'bg-red-950/60 border border-red-500/60 text-white rounded-tl-none'
                  : 'bg-navy-900/90 border border-slate-800 text-slate-100 rounded-tl-none'
              }`}>
                <p>{msg.text}</p>
                {msg.actionTriggered && (
                  <span className="inline-block mt-2 text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-500/40 font-bold">
                    ACTION EXECUTED: {msg.actionTriggered}
                  </span>
                )}
              </div>
              <span className={`text-[10px] font-mono text-slate-500 mt-1 block ${msg.sender === 'user' ? 'text-right' : ''}`}>
                {msg.timestamp}
              </span>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input & Voice Controls */}
      <div className="p-4 px-6 border-t border-slate-800 bg-navy-900/80">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-3"
        >
          {/* Voice Input Button */}
          <button
            type="button"
            onClick={toggleSpeechRecognition}
            title={isListening ? 'Stop listening' : 'Start speaking'}
            className={`p-3 rounded-xl border transition-all ${
              isListening
                ? 'bg-red-500/20 text-red-400 border-red-500/50 animate-pulse'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white hover:border-cyan-500/40'
            }`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Text Input */}
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              language === 'hi'
                ? "यहाँ टाइप करें या माइक पर बोलें (उदा: 'मदद करो', 'दरवाजा कोई खोल रहा है')..."
                : language === 'hinglish'
                ? "Type or speak hands-free (e.g. 'Help me weak lag raha hai', 'Doctor ko call karo')..."
                : "Type message or speak hands-free (e.g. 'Help me I fell down', 'Call my son')..."
            }
            className="flex-1 bg-navy-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/60"
          />

          {/* Send Button */}
          <button
            type="submit"
            disabled={!inputText.trim() || loading}
            className="p-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-navy-950 font-bold transition-all shadow-md shadow-cyan-950"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>

    </div>
  );
};

