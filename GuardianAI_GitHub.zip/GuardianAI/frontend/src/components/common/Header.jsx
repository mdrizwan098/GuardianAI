import React from 'react';
import { Shield, Eye, EyeOff, Mic, MicOff, Video, VideoOff, PhoneCall, Radio, AlertTriangle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { usePrivacy } from '../../context/PrivacyContext';
import { useEmergency } from '../../context/EmergencyContext';

export const Header = ({ activeTab, setActiveTab }) => {
  const { user, household } = useAuth();
  const { privacyMode, togglePrivacy, cameraHardwareActive, micHardwareActive } = usePrivacy();
  const { activeEmergency, triggerManualSOS } = useEmergency();

  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b border-slate-800/80 bg-navy-950/90 px-4 lg:px-8 py-3 transition-all duration-300">
      <div className="flex items-center justify-between gap-4">
        
        {/* Brand & System Status */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className={`p-2 rounded-xl transition-all ${
                activeEmergency 
                  ? 'bg-red-500/20 text-red-400 ring-2 ring-red-500 animate-pulse'
                  : 'bg-cyan-500/10 text-cyan-400 ring-1 ring-cyan-500/30'
              }`}>
                <Shield className="w-6 h-6" />
              </div>
              <span className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${
                activeEmergency ? 'bg-red-500 animate-ping' : 'bg-emerald-500'
              }`} />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-wider text-white">GUARDIAN<span className="text-cyan-400">AI</span></span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300">
                  Autonomous v1.0
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono flex items-center gap-1.5">
                <span className={`inline-block w-1.5 h-1.5 rounded-full ${privacyMode ? 'bg-amber-400' : 'bg-emerald-400'}`}></span>
                {privacyMode ? 'PRIVACY MODE (Optical Capture Blinded)' : 'AUTONOMOUS SENTRY ACTIVE'}
              </p>
            </div>
          </div>

          {/* Household Locator Badge */}
          <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-navy-900/60 border border-slate-800 text-xs text-slate-300">
            <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span className="font-semibold text-slate-200">{household?.name || ' Sharma Residence'}</span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-400">{household?.address?.city || 'New Delhi'}, IN</span>
          </div>
        </div>

        {/* Center Indicators: Privacy & Hardware States */}
        <div className="hidden md:flex items-center gap-3">
          {/* Emergency 112 Link Badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-blue-950/60 border border-blue-500/30 text-[11px] font-mono text-blue-300">
            <PhoneCall className="w-3 h-3 text-blue-400" />
            <span>ERSS 112: <strong className="text-emerald-400">READY (SIM)</strong></span>
          </div>

          {/* Hardware Camera Indicator */}
          <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-mono transition-all ${
            privacyMode
              ? 'bg-slate-900 border border-slate-800 text-slate-500 line-through'
              : cameraHardwareActive
              ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-300'
              : 'bg-navy-900/60 border border-slate-800 text-slate-400'
          }`}>
            {privacyMode ? <VideoOff className="w-3 h-3 text-red-400" /> : <Video className="w-3 h-3 text-emerald-400" />}
            <span>CAM: {privacyMode ? 'BLOCKED' : cameraHardwareActive ? 'STREAMING' : 'STANDBY'}</span>
          </div>

          {/* Hardware Mic Indicator */}
          <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-mono transition-all ${
            privacyMode
              ? 'bg-slate-900 border border-slate-800 text-slate-500 line-through'
              : micHardwareActive
              ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-300'
              : 'bg-navy-900/60 border border-slate-800 text-slate-400'
          }`}>
            {privacyMode ? <MicOff className="w-3 h-3 text-red-400" /> : <Mic className="w-3 h-3 text-emerald-400" />}
            <span>MIC: {privacyMode ? 'MUTED' : micHardwareActive ? 'LISTENING' : 'STANDBY'}</span>
          </div>
        </div>

        {/* Actions: Privacy Toggle & SOS Panic Trigger */}
        <div className="flex items-center gap-3">
          {/* Privacy Toggle Button */}
          <button
            onClick={togglePrivacy}
            title={privacyMode ? "Disable Privacy Mode (Resume Vision/Audio)" : "Enable Privacy Mode (Blind optical & audio capture)"}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-medium text-xs transition-all duration-200 border ${
              privacyMode
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-slate-900/80 text-slate-300 border-slate-700 hover:border-cyan-500/40 hover:text-cyan-300'
            }`}
          >
            {privacyMode ? <EyeOff className="w-4 h-4 text-amber-400" /> : <Eye className="w-4 h-4 text-cyan-400" />}
            <span className="hidden sm:inline">{privacyMode ? 'Privacy: ON' : 'Privacy Mode'}</span>
          </button>

          {/* Panic SOS Button */}
          <button
            onClick={() => triggerManualSOS('Manual Panic SOS Triggered from Dashboard Header')}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl font-bold text-xs uppercase tracking-wider bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white shadow-lg shadow-red-900/40 border border-red-500/60 transition-all hover:scale-105 active:scale-95"
          >
            <AlertTriangle className="w-4 h-4 animate-bounce" />
            <span>SOS</span>
          </button>

          {/* User Profile avatar */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <div className="w-8 h-8 rounded-full overflow-hidden ring-1 ring-cyan-500/40 bg-slate-800 flex items-center justify-center font-bold text-xs text-cyan-300">
              {user?.name ? user.name[0].toUpperCase() : 'A'}
            </div>
          </div>
        </div>

      </div>
    </header>
  );
};

