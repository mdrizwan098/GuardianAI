import React from 'react';
import { LayoutDashboard, Video, AlertCircle, Users, BotMessageSquare, Cpu } from 'lucide-react';
import { useEmergency } from '../../context/EmergencyContext';

export const NavigationTabs = ({ activeTab, setActiveTab }) => {
  const { activeEmergency } = useEmergency();

  const tabs = [
    { id: 'overview', label: 'SOC Overview', icon: LayoutDashboard },
    { id: 'monitoring', label: 'Live Monitoring & CV', icon: Video },
    {
      id: 'emergency',
      label: 'Emergency Center',
      icon: AlertCircle,
      badge: activeEmergency ? (activeEmergency.riskClassification === 'LEVEL_3_CRITICAL' ? 'L3 CRITICAL' : 'L2 WARNING') : null,
      badgeColor: activeEmergency?.riskClassification === 'LEVEL_3_CRITICAL' ? 'bg-red-500 animate-pulse text-white' : 'bg-amber-500 text-navy-950 font-bold'
    },
    { id: 'family', label: 'Family & Video Calling', icon: Users },
    { id: 'ai_assistant', label: 'Multilingual Voice AI', icon: BotMessageSquare },
    { id: 'iot_audit', label: 'IoT Sim & Audit Logs', icon: Cpu }
  ];

  return (
    <nav className="w-full bg-navy-900/60 border-b border-slate-800/80 px-4 lg:px-8 py-2 overflow-x-auto">
      <div className="flex items-center gap-1.5 min-w-max">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium transition-all duration-200 relative ${
                isActive
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-950'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded-full ${tab.badgeColor}`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};

