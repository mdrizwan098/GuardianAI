import React, { useState, useEffect } from 'react';
import {
  Cpu,
  ShieldCheck,
  Zap,
  Activity,
  Flame,
  DoorOpen,
  Sparkles,
  RefreshCw,
  FileText,
  Lock,
  Battery,
  Wifi,
  Sliders
} from 'lucide-react';
import { api } from '../../services/api';
import { useEmergency } from '../../context/EmergencyContext';

export const IoTEventSimulator = () => {
  const { refreshEmergency } = useEmergency();
  const [devices, setDevices] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [consent, setConsent] = useState(null);
  const [activeSimulation, setActiveSimulation] = useState('');
  const [loading, setLoading] = useState(true);

  const loadAll = async () => {
    try {
      const [devs, logs, cst] = await Promise.all([
        api.getDevices(),
        api.getAuditLogs(25),
        api.getConsent()
      ]);
      setDevices(devs);
      setAuditLogs(logs);
      setConsent(cst);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const handleSimulateEvent = async (simKey, eventPayload) => {
    setActiveSimulation(simKey);
    try {
      await api.triggerDetectionEvent(eventPayload);
      await loadAll();
      refreshEmergency();
    } catch (err) {
      console.error(err);
    } finally {
      setTimeout(() => setActiveSimulation(''), 3000);
    }
  };

  return (
    <div className="space-y-8">
      
      {/* Simulation Controls Banner */}
      <div className="glass-panel rounded-2xl p-6 border border-cyan-500/30">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div>
            <span className="text-[10px] font-mono uppercase bg-cyan-950 text-cyan-400 px-2.5 py-0.5 rounded border border-cyan-500/40 font-bold">
              INTERACTIVE TEST HARNESS
            </span>
            <h2 className="text-xl font-extrabold text-white mt-1">IoT Multi-Sensor Scenario Simulator</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Instantly inject simulated sensor telemetry to test the deterministic safety gate, escalation matrix, and 112 dispatch pipeline.
            </p>
          </div>

          <button
            onClick={loadAll}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono bg-slate-800 text-slate-300 hover:text-white border border-slate-700"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh State</span>
          </button>
        </div>

        {/* Buttons Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          
          {/* Fall Simulation */}
          <button
            onClick={() => handleSimulateEvent('fall', {
              deviceId: 'dev_cam_01',
              eventType: 'fall_detected',
              rawConfidence: 0.94,
              telemetryData: { source: 'Optical MoveNet Kinematics', descentSpeed: '1.9m/s', floorTime: '12s' }
            })}
            className={`p-4 rounded-xl text-left border transition-all ${
              activeSimulation === 'fall'
                ? 'bg-amber-500/30 border-amber-400 ring-2 ring-amber-400'
                : 'bg-navy-900/80 border-slate-800 hover:border-amber-500/50'
            }`}
          >
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 w-fit mb-2">
              <Activity className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-white text-xs">Simulate Elderly Fall</h4>
            <p className="text-[11px] text-slate-400 mt-1">Triggers L2 Warning + 30s voice verification countdown.</p>
          </button>

          {/* Door Breach */}
          <button
            onClick={() => handleSimulateEvent('door', {
              deviceId: 'dev_sensor_01',
              eventType: 'door_forced',
              rawConfidence: 0.92,
              telemetryData: { source: 'Magnetic Contact Sensor', impactForce: '450N', latchBreach: true }
            })}
            className={`p-4 rounded-xl text-left border transition-all ${
              activeSimulation === 'door'
                ? 'bg-red-500/30 border-red-400 ring-2 ring-red-400'
                : 'bg-navy-900/80 border-slate-800 hover:border-red-500/50'
            }`}
          >
            <div className="p-2.5 rounded-lg bg-red-500/10 text-red-400 w-fit mb-2">
              <DoorOpen className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-white text-xs">Simulate Forced Door Breach</h4>
            <p className="text-[11px] text-slate-400 mt-1">Triggers L3 Critical intrusion alert + 112 police alert.</p>
          </button>

          {/* Smoke Alarm */}
          <button
            onClick={() => handleSimulateEvent('smoke', {
              deviceId: 'dev_sensor_02',
              eventType: 'smoke_detected',
              rawConfidence: 0.99,
              telemetryData: { source: 'Optical Chamber Smoke Sensor', ppmLevel: 145, tempC: 62 }
            })}
            className={`p-4 rounded-xl text-left border transition-all ${
              activeSimulation === 'smoke'
                ? 'bg-red-500/30 border-red-400 ring-2 ring-red-400'
                : 'bg-navy-900/80 border-slate-800 hover:border-red-500/50'
            }`}
          >
            <div className="p-2.5 rounded-lg bg-red-500/10 text-red-400 w-fit mb-2">
              <Flame className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-white text-xs">Simulate Kitchen Smoke Alarm</h4>
            <p className="text-[11px] text-slate-400 mt-1">Instant L3 Critical Fire hazard + 112 Fire dispatch.</p>
          </button>

          {/* Glass Break */}
          <button
            onClick={() => handleSimulateEvent('glass', {
              deviceId: 'dev_sensor_03',
              eventType: 'glass_break',
              rawConfidence: 0.88,
              telemetryData: { source: 'Acoustic Resonance Sensor', freqPeak: '4.8kHz' }
            })}
            className={`p-4 rounded-xl text-left border transition-all ${
              activeSimulation === 'glass'
                ? 'bg-blue-500/30 border-blue-400 ring-2 ring-blue-400'
                : 'bg-navy-900/80 border-slate-800 hover:border-blue-500/50'
            }`}
          >
            <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400 w-fit mb-2">
              <Sparkles className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-white text-xs">Simulate Glass Break Transient</h4>
            <p className="text-[11px] text-slate-400 mt-1">Correlated with room activity to detect intrusion.</p>
          </button>

        </div>
      </div>

      {/* Connected Smart Devices Grid */}
      <div>
        <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <Cpu className="w-5 h-5 text-cyan-400" />
          <span>Connected Peripherals & IoT Telemetry Health</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {devices.map((device) => (
            <div key={device._id} className="glass-panel rounded-2xl p-4 border border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono uppercase bg-slate-800 text-cyan-300 px-2 py-0.5 rounded">
                  {device.deviceType}
                </span>
                <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> ONLINE
                </span>
              </div>

              <h4 className="font-bold text-white text-sm">{device.deviceName}</h4>
              <p className="text-xs text-slate-400 font-mono mt-0.5">{device.location}</p>

              <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span className="flex items-center gap-1">
                  <Battery className="w-3.5 h-3.5 text-slate-400" /> {device.batteryLevel}%
                </span>
                <span className="flex items-center gap-1">
                  <Wifi className="w-3.5 h-3.5 text-cyan-400" /> {device.ipAddress}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Immutable Cryptographic Audit Log Viewer */}
      <div>
        <div className="flex items-center justify-between gap-4 mb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Lock className="w-5 h-5 text-emerald-400" />
              <span>Tamper-Evident SHA-256 Audit Trail</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Cryptographically chained immutable history of every sensor trigger, voice challenge, privacy toggle, and emergency dispatch.
            </p>
          </div>
        </div>

        <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
          <div className="overflow-x-auto max-h-96">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-navy-900/90 text-slate-400 uppercase text-[10px] border-b border-slate-800 sticky top-0">
                <tr>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Action</th>
                  <th className="py-3 px-4">Actor</th>
                  <th className="py-3 px-4">Cryptographic Hash (SHA-256)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {auditLogs.map((log) => (
                  <tr key={log._id} className="hover:bg-slate-800/30 transition-all">
                    <td className="py-2.5 px-4 text-slate-400 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </td>
                    <td className="py-2.5 px-4 font-bold text-white">
                      {log.action}
                    </td>
                    <td className="py-2.5 px-4 text-cyan-400">
                      {log.actor}
                    </td>
                    <td className="py-2.5 px-4 text-slate-500 font-mono text-[11px] truncate max-w-xs">
                      {log.hash ? `${log.hash.substring(0, 16)}...${log.hash.substring(log.hash.length - 8)}` : 'N/A'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  );
};

