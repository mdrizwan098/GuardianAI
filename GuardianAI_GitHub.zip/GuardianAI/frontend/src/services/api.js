const API_BASE = '/api';

const getHeaders = () => {
  const token = localStorage.getItem('guardian_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };
};

export const api = {
  // Auth
  async login(email, password) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) throw new Error((await res.json()).error || 'Login failed');
    return res.json();
  },

  async getMe() {
    const res = await fetch(`${API_BASE}/auth/me`, { headers: getHeaders() });
    if (!res.ok) throw new Error('Failed to load user profile');
    return res.json();
  },

  // Household
  async getHousehold() {
    const res = await fetch(`${API_BASE}/households`, { headers: getHeaders() });
    return res.json();
  },

  async togglePrivacyMode(active) {
    const res = await fetch(`${API_BASE}/households/privacy-mode`, {
      method: 'PATCH',
      headers: getHeaders(),
      body: JSON.stringify({ active })
    });
    return res.json();
  },

  // Family
  async getFamilyMembers() {
    const res = await fetch(`${API_BASE}/family`, { headers: getHeaders() });
    return res.json();
  },

  async addFamilyMember(data) {
    const res = await fetch(`${API_BASE}/family`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async updateMemberStatus(id, status) {
    const res = await fetch(`${API_BASE}/family/${id}/status`, {
      method: 'PATCH',
      headers: getHeaders(),
      body: JSON.stringify({ status })
    });
    return res.json();
  },

  // Emergency Contacts
  async getContacts() {
    const res = await fetch(`${API_BASE}/contacts`, { headers: getHeaders() });
    return res.json();
  },

  async addContact(data) {
    const res = await fetch(`${API_BASE}/contacts`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    return res.json();
  },

  // Devices & Sensors
  async getDevices() {
    const res = await fetch(`${API_BASE}/devices`, { headers: getHeaders() });
    return res.json();
  },

  async triggerDetectionEvent(data) {
    const res = await fetch(`${API_BASE}/events/detect`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async getRecentEvents() {
    const res = await fetch(`${API_BASE}/events/recent`, { headers: getHeaders() });
    return res.json();
  },

  // AI Conversational Triage
  async submitAITriage(message, language = 'en') {
    const res = await fetch(`${API_BASE}/ai/triage`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ message, language })
    });
    return res.json();
  },

  async getPrompts(language = 'en') {
    const res = await fetch(`${API_BASE}/ai/prompts?lang=${language}`, { headers: getHeaders() });
    return res.json();
  },

  // Emergency State Management
  async getActiveEmergency() {
    const res = await fetch(`${API_BASE}/emergency/active`, { headers: getHeaders() });
    return res.json();
  },

  async confirmEmergency(eventId, isSafe, notes = '') {
    const res = await fetch(`${API_BASE}/emergency/confirm`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ eventId, isSafe, notes })
    });
    return res.json();
  },

  async escalateEmergency(eventId, reason = '') {
    const res = await fetch(`${API_BASE}/emergency/escalate`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ eventId, reason })
    });
    return res.json();
  },

  async dispatch112(eventId, serviceType = 'ALL', triggerReason = '') {
    const res = await fetch(`${API_BASE}/emergency/dispatch-112`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ eventId, serviceType, triggerReason })
    });
    return res.json();
  },

  async connectDoctor(eventId, doctorContactId) {
    const res = await fetch(`${API_BASE}/emergency/connect-doctor`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ eventId, doctorContactId })
    });
    return res.json();
  },

  async getEmergencyHistory() {
    const res = await fetch(`${API_BASE}/emergency/history`, { headers: getHeaders() });
    return res.json();
  },

  // Calls
  async initiateCall(receiverId, callType = 'family_video') {
    const res = await fetch(`${API_BASE}/calls/initiate`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ receiverId, callType })
    });
    return res.json();
  },

  async getCallHistory() {
    const res = await fetch(`${API_BASE}/calls/history`, { headers: getHeaders() });
    return res.json();
  },

  // Consent & Audit
  async getConsent() {
    const res = await fetch(`${API_BASE}/consent`, { headers: getHeaders() });
    return res.json();
  },

  async updateConsent(data) {
    const res = await fetch(`${API_BASE}/consent`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async getAuditLogs(limit = 50) {
    const res = await fetch(`${API_BASE}/audit?limit=${limit}`, { headers: getHeaders() });
    return res.json();
  }
};

