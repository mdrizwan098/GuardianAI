import { Server } from 'socket.io';

let ioInstance = null;

export const initSocket = (httpServer, clientOrigin) => {
  ioInstance = new Server(httpServer, {
    cors: {
      origin: clientOrigin || '*',
      methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE'],
      credentials: true
    }
  });

  const activeRooms = new Map();

  ioInstance.on('connection', (socket) => {
    console.log(`[Socket] Client connected: ${socket.id}`);

    // Join household specific channel
    socket.on('join:household', (householdId) => {
      socket.join(`household:${householdId}`);
      console.log(`[Socket] ${socket.id} joined household:${householdId}`);
    });

    // WebRTC Signaling Handlers
    socket.on('webrtc:join_call', ({ roomId, userId, userName, callType }) => {
      socket.join(`call:${roomId}`);
      if (!activeRooms.has(roomId)) {
        activeRooms.set(roomId, new Set());
      }
      activeRooms.get(roomId).add(socket.id);

      console.log(`[WebRTC] User ${userName} (${userId}) joined room ${roomId}`);

      // Notify others in room
      socket.to(`call:${roomId}`).emit('webrtc:user_joined', {
        peerId: socket.id,
        userId,
        userName,
        callType
      });
    });

    socket.on('webrtc:offer', ({ to, offer, fromUser }) => {
      ioInstance.to(to).emit('webrtc:offer', {
        from: socket.id,
        offer,
        fromUser
      });
    });

    socket.on('webrtc:answer', ({ to, answer, fromUser }) => {
      ioInstance.to(to).emit('webrtc:answer', {
        from: socket.id,
        answer,
        fromUser
      });
    });

    socket.on('webrtc:ice_candidate', ({ to, candidate }) => {
      ioInstance.to(to).emit('webrtc:ice_candidate', {
        from: socket.id,
        candidate
      });
    });

    socket.on('webrtc:leave_call', ({ roomId, userId }) => {
      socket.leave(`call:${roomId}`);
      if (activeRooms.has(roomId)) {
        activeRooms.get(roomId).delete(socket.id);
        if (activeRooms.get(roomId).size === 0) {
          activeRooms.delete(roomId);
        }
      }
      socket.to(`call:${roomId}`).emit('webrtc:user_left', {
        peerId: socket.id,
        userId
      });
      console.log(`[WebRTC] User ${userId} left room ${roomId}`);
    });

    socket.on('disconnect', () => {
      console.log(`[Socket] Client disconnected: ${socket.id}`);
      for (const [roomId, socketSet] of activeRooms.entries()) {
        if (socketSet.has(socket.id)) {
          socketSet.delete(socket.id);
          socket.to(`call:${roomId}`).emit('webrtc:user_left', { peerId: socket.id });
          if (socketSet.size === 0) activeRooms.delete(roomId);
        }
      }
    });
  });

  return ioInstance;
};

export const getIO = () => {
  return ioInstance;
};

