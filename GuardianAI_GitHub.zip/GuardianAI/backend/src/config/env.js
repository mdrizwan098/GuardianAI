import dotenv from 'dotenv';
dotenv.config();

export const ENV = {
  PORT: process.env.PORT || 5001,
  NODE_ENV: process.env.NODE_ENV || 'development',
  JWT_SECRET: process.env.JWT_SECRET || 'guardianai_super_secret_production_key_2026',
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/guardianai',
  REDIS_URL: process.env.REDIS_URL || 'redis://127.0.0.1:6379',
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || '',
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || '',
  EMERGENCY_DISPATCH_MODE: process.env.EMERGENCY_DISPATCH_MODE || 'simulation', // 'simulation' | 'live'
  SMS_GATEWAY_MODE: process.env.SMS_GATEWAY_MODE || 'simulation', // 'simulation' | 'live'
  DEFAULT_COUNTRY: process.env.DEFAULT_COUNTRY || 'IN',
  DEFAULT_EMERGENCY_NUMBER: process.env.DEFAULT_EMERGENCY_NUMBER || '112',
  CLIENT_ORIGIN: process.env.CLIENT_ORIGIN || 'http://localhost:5173'
};

