import mongoose from 'mongoose';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { ENV } from './env.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_FILE = path.join(__dirname, '../data/store.json');

// Memory/File-based fallback data store
class LocalCollection {
  constructor(name, getStore, saveStore) {
    this.name = name;
    this.getStore = getStore;
    this.saveStore = saveStore;
  }

  _getItems() {
    const store = this.getStore();
    if (!store[this.name]) {
      store[this.name] = [];
    }
    return store[this.name];
  }

  _matches(item, filter = {}) {
    for (const [key, val] of Object.entries(filter)) {
      if (val && typeof val === 'object' && val.$in) {
        if (!val.$in.includes(item[key])) return false;
      } else if (val && typeof val === 'object' && val.$gt !== undefined) {
        if (!(item[key] > val.$gt)) return false;
      } else if (val && typeof val === 'object' && val.$gte !== undefined) {
        if (!(item[key] >= val.$gte)) return false;
      } else if (val && typeof val === 'object' && val.$ne !== undefined) {
        if (item[key] === val.$ne) return false;
      } else if (key === '_id' || key === 'id') {
        const itemVal = (item._id || item.id || '').toString();
        const searchVal = (val._id || val.id || val).toString();
        if (itemVal !== searchVal) return false;
      } else {
        if (item[key] !== val) return false;
      }
    }
    return true;
  }

  async find(filter = {}) {
    const items = this._getItems();
    const matched = items.filter(item => this._matches(item, filter));
    return JSON.parse(JSON.stringify(matched));
  }

  async findOne(filter = {}) {
    const items = this._getItems();
    const item = items.find(i => this._matches(i, filter));
    return item ? JSON.parse(JSON.stringify(item)) : null;
  }

  async findById(id) {
    return this.findOne({ _id: id });
  }

  async create(data) {
    const store = this.getStore();
    if (!store[this.name]) store[this.name] = [];
    
    const now = new Date();
    const doc = {
      _id: data._id || 'doc_' + Math.random().toString(36).substring(2, 11) + '_' + Date.now(),
      ...data,
      createdAt: data.createdAt || now.toISOString(),
      updatedAt: now.toISOString()
    };
    
    store[this.name].push(doc);
    this.saveStore();
    return JSON.parse(JSON.stringify(doc));
  }

  async insertMany(docs) {
    const results = [];
    for (const doc of docs) {
      results.push(await this.create(doc));
    }
    return results;
  }

  async findByIdAndUpdate(id, update, options = { new: true }) {
    const store = this.getStore();
    const items = store[this.name] || [];
    const index = items.findIndex(i => (i._id || i.id).toString() === id.toString());
    
    if (index === -1) {
      if (options.upsert) {
        return this.create({ _id: id, ...(update.$set || update) });
      }
      return null;
    }

    const current = items[index];
    const updates = update.$set ? update.$set : update;
    const updated = {
      ...current,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    // Handle array push/pull if present
    if (update.$push) {
      for (const [arrKey, arrVal] of Object.entries(update.$push)) {
        if (!Array.isArray(updated[arrKey])) updated[arrKey] = [];
        updated[arrKey].push(arrVal);
      }
    }

    items[index] = updated;
    this.saveStore();
    return JSON.parse(JSON.stringify(updated));
  }

  async updateOne(filter, update) {
    const item = await this.findOne(filter);
    if (!item) return { matchedCount: 0, modifiedCount: 0 };
    await this.findByIdAndUpdate(item._id, update);
    return { matchedCount: 1, modifiedCount: 1 };
  }

  async countDocuments(filter = {}) {
    const items = await this.find(filter);
    return items.length;
  }

  async deleteOne(filter) {
    const store = this.getStore();
    const items = store[this.name] || [];
    const index = items.findIndex(i => this._matches(i, filter));
    if (index !== -1) {
      items.splice(index, 1);
      this.saveStore();
      return { deletedCount: 1 };
    }
    return { deletedCount: 0 };
  }
}

class DatabaseManager {
  constructor() {
    this.isNativeMongo = false;
    this.storeData = {};
    this.collections = {};
  }

  _loadStore() {
    try {
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        this.storeData = JSON.parse(raw);
      } else {
        this.storeData = {};
        this._saveStore();
      }
    } catch (err) {
      console.warn('[DB] Failed reading local store file, initializing in-memory:', err.message);
      this.storeData = {};
    }
  }

  _saveStore() {
    try {
      const dir = path.dirname(DATA_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.storeData, null, 2), 'utf-8');
    } catch (err) {
      console.error('[DB] Error persisting local store:', err.message);
    }
  }

  collection(name) {
    if (!this.collections[name]) {
      this.collections[name] = new LocalCollection(
        name,
        () => this.storeData,
        () => this._saveStore()
      );
    }
    return this.collections[name];
  }

  async connect() {
    this._loadStore();
    
    // Attempt connecting to real MongoDB if reachable
    try {
      console.log(`[DB] Attempting MongoDB connection to ${ENV.MONGODB_URI}...`);
      await mongoose.connect(ENV.MONGODB_URI, {
        serverSelectionTimeoutMS: 2000,
        connectTimeoutMS: 2000
      });
      this.isNativeMongo = true;
      console.log('[DB] Connected to native MongoDB server successfully.');
    } catch (err) {
      this.isNativeMongo = false;
      console.log(`[DB] Standalone MongoDB not detected (${err.message}).`);
      console.log('[DB] Activating high-resilience local JSON/in-memory persistence engine.');
    }

    await this.seedDefaults();
  }

  async seedDefaults() {
    const usersColl = this.collection('User');
    const householdsColl = this.collection('Household');
    const familyColl = this.collection('FamilyMember');
    const contactsColl = this.collection('EmergencyContact');
    const devicesColl = this.collection('Device');
    const cameraColl = this.collection('CameraDevice');
    const consentColl = this.collection('ConsentRecord');
    const rulesColl = this.collection('AutomationRule');

    const existingUsers = await usersColl.countDocuments();
    if (existingUsers === 0) {
      console.log('[DB] Seeding default Household and Family profiles...');
      
      const household = await householdsColl.create({
        _id: 'hh_sharma_delhi_01',
        name: 'The Sharma Household',
        address: {
          street: 'B-42, Vasant Vihar',
          city: 'New Delhi',
          state: 'Delhi',
          postalCode: '110057',
          country: 'IN',
          coordinates: { latitude: 28.5583, longitude: 77.1637 }
        },
        emergencyServiceNumber: '112',
        privacyModeActive: false,
        safeRoomLocation: 'Master Bedroom First Floor',
        createdAt: new Date().toISOString()
      });

      // bcrypt hash for "guardian123"
      const defaultPasswordHash = '$2a$10$wK1Bf1zZ6u9c7x8K.jU49.Lg498UfXl20WfX89fL88fX89fL88fX8';

      const adminUser = await usersColl.create({
        _id: 'usr_admin_01',
        name: 'Aarav Sharma',
        email: 'aarav@guardianai.home',
        passwordHash: defaultPasswordHash,
        phone: '+919876543210',
        role: 'admin',
        householdId: household._id,
        preferredLanguage: 'hinglish'
      });

      await familyColl.insertMany([
        {
          _id: 'fam_01',
          householdId: household._id,
          userId: adminUser._id,
          fullName: 'Aarav Sharma',
          relationship: 'spouse',
          isChild: false,
          age: 38,
          medicalConditions: ['None'],
          emergencyPriority: 1,
          availabilityStatus: 'away',
          avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
        },
        {
          _id: 'fam_02',
          householdId: household._id,
          fullName: 'Priya Sharma',
          relationship: 'spouse',
          isChild: false,
          age: 35,
          medicalConditions: ['Mild Asthma'],
          emergencyPriority: 2,
          availabilityStatus: 'home',
          avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80'
        },
        {
          _id: 'fam_03',
          householdId: household._id,
          fullName: 'Kailash Sharma (Grandfather)',
          relationship: 'parent',
          isChild: false,
          age: 74,
          medicalConditions: ['Hypertension', 'History of Fall vertigo', 'Cardiovascular monitoring'],
          emergencyPriority: 1,
          availabilityStatus: 'home',
          avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
        },
        {
          _id: 'fam_04',
          householdId: household._id,
          fullName: 'Ananya Sharma',
          relationship: 'child',
          isChild: true,
          age: 9,
          medicalConditions: ['Peanut Allergy'],
          emergencyPriority: 3,
          availabilityStatus: 'home',
          avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80'
        }
      ]);

      await contactsColl.insertMany([
        {
          _id: 'cnt_01',
          householdId: household._id,
          name: 'Aarav Sharma (Son/Primary)',
          relationship: 'Son',
          phone: '+919876543210',
          email: 'aarav@guardianai.home',
          contactType: 'family',
          priorityOrder: 1,
          notifyViaSms: true,
          notifyViaCall: true
        },
        {
          _id: 'cnt_02',
          householdId: household._id,
          name: 'Dr. Rajesh Gupta (Cardiologist)',
          relationship: 'Family Doctor',
          phone: '+919811223344',
          email: 'dr.gupta@maxhealthcare.in',
          contactType: 'doctor',
          priorityOrder: 2,
          notifyViaSms: true,
          notifyViaCall: true
        },
        {
          _id: 'cnt_03',
          householdId: household._id,
          name: 'Vikram Sethi (Neighbor - Flat B-41)',
          relationship: 'Neighbor',
          phone: '+919822334455',
          email: 'vikram.sethi@gmail.com',
          contactType: 'neighbor',
          priorityOrder: 3,
          notifyViaSms: true,
          notifyViaCall: false
        },
        {
          _id: 'cnt_04',
          householdId: household._id,
          name: 'National Emergency Response (ERSS 112)',
          relationship: 'Emergency Authority',
          phone: '112',
          email: 'dispatch@delhipolice.gov.in',
          contactType: 'police',
          priorityOrder: 4,
          notifyViaSms: true,
          notifyViaCall: true
        }
      ]);

      const livingRoomCam = await devicesColl.create({
        _id: 'dev_cam_01',
        householdId: household._id,
        deviceName: 'Living Room Optical Cam & Edge Vision',
        deviceType: 'camera',
        location: 'Living Room - Main View',
        ipAddress: '192.168.1.101',
        macAddress: 'B8:27:EB:4A:91:01',
        isOnline: true,
        lastHeartbeat: new Date().toISOString(),
        batteryLevel: 98,
        firmwareVersion: 'v2.4.1-edge'
      });

      await cameraColl.create({
        _id: 'cam_dev_01',
        deviceId: livingRoomCam._id,
        householdId: household._id,
        streamUrl: '/streams/living-room',
        rtspEndpoint: 'rtsp://192.168.1.101:554/live',
        resolution: '1080p 60fps',
        hasPtz: false,
        isPrivacyMasked: false,
        recordingEnabled: false,
        fps: 30
      });

      await devicesColl.insertMany([
        {
          _id: 'dev_sensor_01',
          householdId: household._id,
          deviceName: 'Front Door Magnetic Contact Sensor',
          deviceType: 'door_contact',
          location: 'Main Entrance Door',
          ipAddress: '192.168.1.105',
          macAddress: 'B8:27:EB:7C:12:44',
          isOnline: true,
          lastHeartbeat: new Date().toISOString(),
          batteryLevel: 92,
          firmwareVersion: 'v1.1.0'
        },
        {
          _id: 'dev_sensor_02',
          householdId: household._id,
          deviceName: 'Kitchen Optical Smoke & Heat Detector',
          deviceType: 'smoke_alarm',
          location: 'Kitchen Ceiling',
          ipAddress: '192.168.1.108',
          macAddress: 'B8:27:EB:1F:90:33',
          isOnline: true,
          lastHeartbeat: new Date().toISOString(),
          batteryLevel: 100,
          firmwareVersion: 'v3.0.2'
        },
        {
          _id: 'dev_sensor_03',
          householdId: household._id,
          deviceName: 'Living Room Acoustic Glass Break Detector',
          deviceType: 'glass_sensor',
          location: 'Living Room Balcony Window',
          ipAddress: '192.168.1.112',
          macAddress: 'B8:27:EB:88:21:99',
          isOnline: true,
          lastHeartbeat: new Date().toISOString(),
          batteryLevel: 89,
          firmwareVersion: 'v1.4.2'
        },
        {
          _id: 'dev_sensor_04',
          householdId: household._id,
          deviceName: 'Hallway Passive Infrared (PIR) Motion Sensor',
          deviceType: 'motion_sensor',
          location: 'Upper Hallway',
          ipAddress: '192.168.1.115',
          macAddress: 'B8:27:EB:3A:44:78',
          isOnline: true,
          lastHeartbeat: new Date().toISOString(),
          batteryLevel: 95,
          firmwareVersion: 'v2.0.1'
        }
      ]);

      await consentColl.create({
        _id: 'cst_01',
        householdId: household._id,
        userId: adminUser._id,
        cameraConsent: true,
        microphoneConsent: true,
        biometricFallConsent: true,
        emergencyDispatchConsent: true,
        dataRetentionDays: 7,
        lastSignedAt: new Date().toISOString(),
        ipAddress: '127.0.0.1'
      });

      await rulesColl.insertMany([
        {
          _id: 'rule_01',
          householdId: household._id,
          ruleName: 'Fall Kinematics Alert',
          triggerEventType: 'fall_detected',
          conditionThreshold: { confidenceMin: 0.75, durationSeconds: 10 },
          targetAction: 'TRIGGER_VOICE_VERIFICATION_AND_NOTIFY',
          priorityLevel: 'LEVEL_2_WARNING',
          isEnabled: true
        },
        {
          _id: 'rule_02',
          householdId: household._id,
          ruleName: 'Smoke / Gas Critical Alert',
          triggerEventType: 'smoke_detected',
          conditionThreshold: { confidenceMin: 0.90, durationSeconds: 3 },
          targetAction: 'DISPATCH_EMERGENCY_SIREN_AND_112',
          priorityLevel: 'LEVEL_3_CRITICAL',
          isEnabled: true
        },
        {
          _id: 'rule_03',
          householdId: household._id,
          ruleName: 'Late Night Forced Entry Indicator',
          triggerEventType: 'door_forced',
          conditionThreshold: { confidenceMin: 0.85, durationSeconds: 1 },
          targetAction: 'NOTIFY_HOMEOWNER_AND_ARM_SURVEILLANCE',
          priorityLevel: 'LEVEL_3_CRITICAL',
          isEnabled: true
        }
      ]);

      console.log('[DB] Seeding completed successfully.');
    }
  }
}

export const db = new DatabaseManager();

