// Resilient Cache Manager: In-Memory / Redis Interface
class MemoryCache {
  constructor() {
    this.store = new Map();
    this.ttls = new Map();
  }

  async get(key) {
    if (!this.store.has(key)) return null;
    const expiresAt = this.ttls.get(key);
    if (expiresAt && Date.now() > expiresAt) {
      this.del(key);
      return null;
    }
    const val = this.store.get(key);
    try {
      return JSON.parse(val);
    } catch {
      return val;
    }
  }

  async set(key, value, ttlSeconds = 0) {
    const serialized = typeof value === 'object' ? JSON.stringify(value) : String(value);
    this.store.set(key, serialized);
    if (ttlSeconds > 0) {
      this.ttls.set(key, Date.now() + ttlSeconds * 1000);
    } else {
      this.ttls.delete(key);
    }
    return true;
  }

  async del(key) {
    this.store.delete(key);
    this.ttls.delete(key);
    return true;
  }

  async flush() {
    this.store.clear();
    this.ttls.clear();
  }
}

export const cache = new MemoryCache();

