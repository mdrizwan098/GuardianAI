import express from 'express';
import http from 'http';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { ENV } from './config/env.js';
import { db } from './config/database.js';
import { initSocket } from './config/socket.js';
import { errorHandler } from './middleware/errorHandler.js';

import authRoutes from './routes/authRoutes.js';
import householdRoutes from './routes/householdRoutes.js';
import familyRoutes from './routes/familyRoutes.js';
import contactRoutes from './routes/contactRoutes.js';
import deviceRoutes from './routes/deviceRoutes.js';
import eventRoutes from './routes/eventRoutes.js';
import aiRoutes from './routes/aiRoutes.js';
import emergencyRoutes from './routes/emergencyRoutes.js';
import callRoutes from './routes/callRoutes.js';
import consentRoutes from './routes/consentRoutes.js';
import auditRoutes from './routes/auditRoutes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = http.createServer(app);

// Setup WebSockets
const io = initSocket(httpServer, ENV.CLIENT_ORIGIN);

// Middleware
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    system: 'GuardianAI Core Platform',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    database: db.isNativeMongo ? 'Native MongoDB' : 'High-Resilience Persistent JSON/Memory Store',
    emergencyDispatchMode: ENV.EMERGENCY_DISPATCH_MODE,
    smsGatewayMode: ENV.SMS_GATEWAY_MODE
  });
});

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/households', householdRoutes);
app.use('/api/family', familyRoutes);
app.use('/api/contacts', contactRoutes);
app.use('/api/devices', deviceRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/emergency', emergencyRoutes);
app.use('/api/calls', callRoutes);
app.use('/api/consent', consentRoutes);
app.use('/api/audit', auditRoutes);

// Static frontend serving if built
const frontendDistPath = path.join(__dirname, '../../frontend/dist');
if (fs.existsSync(frontendDistPath)) {
  console.log(`[HTTP] Serving compiled frontend bundle from ${frontendDistPath}`);
  app.use(express.static(frontendDistPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(frontendDistPath, 'index.html'));
  });
}

// Error Handling Middleware
app.use(errorHandler);

// Boot Server
async function startServer() {
  try {
    await db.connect();
    httpServer.listen(ENV.PORT, () => {
      console.log(`\n======================================================`);
      console.log(`🛡️  GuardianAI Core Server running on port ${ENV.PORT}`);
      console.log(`🛡️  Environment: ${ENV.NODE_ENV}`);
      console.log(`🛡️  Emergency Dispatch Mode: ${ENV.EMERGENCY_DISPATCH_MODE.toUpperCase()}`);
      console.log(`🛡️  SMS Gateway Mode: ${ENV.SMS_GATEWAY_MODE.toUpperCase()}`);
      console.log(`🛡️  Ready to protect household members.`);
      console.log(`======================================================\n`);
    });
  } catch (err) {
    console.error('[FATAL] Failed to boot GuardianAI backend:', err);
    process.exit(1);
  }
}

startServer();

export { app, httpServer };
