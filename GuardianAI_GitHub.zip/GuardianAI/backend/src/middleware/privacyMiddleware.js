import { db } from '../config/database.js';

export const checkPrivacyMode = async (req, res, next) => {
  try {
    const householdId = req.user?.householdId || req.body?.householdId || req.params?.householdId;
    if (!householdId) return next();

    const household = await db.collection('Household').findById(householdId);
    if (household && household.privacyModeActive) {
      req.privacyModeActive = true;
    } else {
      req.privacyModeActive = false;
    }
    next();
  } catch (err) {
    next();
  }
};

