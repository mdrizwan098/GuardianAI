import { db } from '../config/database.js';
import { cache } from '../config/cache.js';
import { getIO } from '../config/socket.js';
import { notificationService } from './notificationService.js';
import { emergencyDispatchService } from './emergencyDispatchService.js';
import { auditService } from './auditService.js';

class EscalationEngine {
  constructor() {
    this.activeTimers = new Map(); // eventId -> setInterval/setTimeout references
  }

  async triggerEmergency({ householdId, eventType, riskLevel, confidenceScore, primaryReason, corroboratingSignals = [] }) {
    const io = getIO();
    const eventId = `EVT_${Date.now()}_${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    // 1. Create EmergencyEvent
    const emergencyDoc = await db.collection('EmergencyEvent').create({
      eventId,
      householdId,
      eventType,
      riskClassification: riskLevel,
      confidenceScore,
      verificationStatus: riskLevel === 'LEVEL_1_INFO' ? 'user_confirmed_safe' : 'awaiting_user',
      actionsInitiated: [],
      notificationStatus: 'pending',
      resolutionStatus: 'active'
    });

    // 2. Create RiskAssessment record
    await db.collection('RiskAssessment').create({
      emergencyEventId: emergencyDoc._id,
      householdId,
      assessedLevel: riskLevel,
      confidenceScore,
      primarySignals: [{ sensorType: eventType, signalValue: primaryReason, confidence: confidenceScore }],
      corroboratingSignals,
      aiReasoningSummary: primaryReason,
      deterministicRuleTriggered: `ESCALATION_RULE_${riskLevel}`,
      evaluatedAt: new Date().toISOString()
    });

    await auditService.log({
      householdId,
      action: `EMERGENCY_${riskLevel}_TRIGGERED`,
      actor: 'escalation_engine',
      details: { eventId, eventType, riskLevel, primaryReason, confidenceScore }
    });

    // 3. Handle by Risk Level
    if (riskLevel === 'LEVEL_1_INFO') {
      if (io) {
        io.to(`household:${householdId}`).emit('emergency:new', {
          event: emergencyDoc,
          reason: primaryReason,
          countdown: 0
        });
      }
      return emergencyDoc;
    }

    if (riskLevel === 'LEVEL_2_WARNING') {
      const countdownSeconds = 30;
      await this.startCountdown(householdId, emergencyDoc, countdownSeconds, 'LEVEL_2_WARNING');

      // Send initial warning notifications to primary family contact
      const primaryContact = await db.collection('EmergencyContact').findOne({ householdId, priorityOrder: 1 });
      if (primaryContact) {
        await notificationService.dispatch({
          householdId,
          emergencyEventId: emergencyDoc._id,
          recipient: primaryContact,
          channel: 'sms',
          message: `GuardianAI WARNING: ${primaryReason}. Voice challenge initiated in home.`
        });
      }

      if (io) {
        io.to(`household:${householdId}`).emit('emergency:new', {
          event: emergencyDoc,
          reason: primaryReason,
          countdown: countdownSeconds,
          voiceChallenge: 'Are you alright? I detected a possible issue. Do you need medical assistance?'
        });
      }

      return emergencyDoc;
    }

    if (riskLevel === 'LEVEL_3_CRITICAL') {
      const abortWindowSeconds = 15;
      await this.startCountdown(householdId, emergencyDoc, abortWindowSeconds, 'LEVEL_3_CRITICAL');

      if (io) {
        io.to(`household:${householdId}`).emit('emergency:new', {
          event: emergencyDoc,
          reason: primaryReason,
          countdown: abortWindowSeconds,
          criticalAlert: true
        });
      }

      return emergencyDoc;
    }

    return emergencyDoc;
  }

  async startCountdown(householdId, emergencyDoc, initialSeconds, currentLevel) {
    const eventId = emergencyDoc.eventId;
    this.clearCountdown(eventId);

    let remaining = initialSeconds;
    await cache.set(`countdown:${eventId}`, remaining, initialSeconds + 5);

    const intervalId = setInterval(async () => {
      remaining -= 1;
      await cache.set(`countdown:${eventId}`, remaining, remaining + 5);

      const io = getIO();
      if (io) {
        io.to(`household:${householdId}`).emit('emergency:countdown_tick', {
          eventId,
          remainingSeconds: remaining,
          level: currentLevel
        });
      }

      if (remaining <= 0) {
        this.clearCountdown(eventId);
        await this.handleCountdownExpiry(householdId, emergencyDoc, currentLevel);
      }
    }, 1000);

    this.activeTimers.set(eventId, intervalId);
  }

  clearCountdown(eventId) {
    if (this.activeTimers.has(eventId)) {
      clearInterval(this.activeTimers.get(eventId));
      this.activeTimers.delete(eventId);
    }
  }

  async handleCountdownExpiry(householdId, emergencyDoc, levelExpired) {
    console.log(`[ESCALATION] Countdown expired for event ${emergencyDoc.eventId} (${levelExpired}). Executing deterministic escalation...`);
    const io = getIO();

    if (levelExpired === 'LEVEL_2_WARNING') {
      // Escalates to LEVEL 3 CRITICAL
      await db.collection('EmergencyEvent').findByIdAndUpdate(emergencyDoc._id, {
        riskClassification: 'LEVEL_3_CRITICAL',
        verificationStatus: 'timed_out_escalated'
      });

      // Dispatch 112 emergency and blast family contacts
      await emergencyDispatchService.dispatch112({
        householdId,
        emergencyEventId: emergencyDoc._id,
        serviceType: emergencyDoc.eventType === 'medical_fall' ? 'AMBULANCE' : 'ALL',
        triggerReason: 'Unresponsive household member following fall detection (30s timer expired)'
      });

      await notificationService.broadcastToHouseholdContacts(
        householdId,
        emergencyDoc._id,
        'CRITICAL ESCALATION',
        'Fall detected and resident is unresponsive. Emergency 112 dispatched.'
      );

      if (io) {
        io.to(`household:${householdId}`).emit('emergency:escalated', {
          eventId: emergencyDoc.eventId,
          newLevel: 'LEVEL_3_CRITICAL',
          reason: 'User unresponsive to voice verification. Automated emergency dispatch triggered.'
        });
      }
    } else if (levelExpired === 'LEVEL_3_CRITICAL') {
      // Direct 112 dispatch execution
      await emergencyDispatchService.dispatch112({
        householdId,
        emergencyEventId: emergencyDoc._id,
        serviceType: 'ALL',
        triggerReason: 'Critical emergency countdown completed without user abort'
      });

      await notificationService.broadcastToHouseholdContacts(
        householdId,
        emergencyDoc._id,
        'CRITICAL EMERGENCY CONFIRMED',
        'Emergency response team notified.'
      );
    }
  }

  async confirmEmergency(householdId, eventId, isSafe, userNotes = '') {
    this.clearCountdown(eventId);
    const emergency = await db.collection('EmergencyEvent').findOne({ eventId });
    if (!emergency) throw new Error('Emergency event not found');

    const updated = await db.collection('EmergencyEvent').findByIdAndUpdate(emergency._id, {
      verificationStatus: isSafe ? 'user_confirmed_safe' : 'user_confirmed_help',
      resolutionStatus: isSafe ? 'resolved' : 'escalated',
      resolvedAt: isSafe ? new Date().toISOString() : null,
      resolvedBy: 'User Confirmation Dialogue'
    });

    await auditService.log({
      householdId,
      action: isSafe ? 'USER_MARKED_SAFE' : 'USER_REQUESTED_HELP',
      actor: 'user',
      details: { eventId, isSafe, userNotes }
    });

    const io = getIO();
    if (isSafe) {
      if (io) {
        io.to(`household:${householdId}`).emit('emergency:resolved', {
          eventId,
          status: 'resolved',
          message: 'Resident verified safety. Emergency standing down.'
        });
      }
    } else {
      // Immediate Level 3 escalation
      await this.handleCountdownExpiry(householdId, emergency, 'LEVEL_2_WARNING');
    }

    return updated;
  }
}

export const escalationEngine = new EscalationEngine();

