import crypto from 'crypto';
import { db } from '../config/database.js';

class AuditService {
  constructor() {
    this.lastHash = '0000000000000000000000000000000000000000000000000000000000000000';
  }

  _computeHash(entry) {
    const payload = `${this.lastHash}|${entry.householdId}|${entry.action}|${entry.actor}|${JSON.stringify(entry.details)}|${entry.timestamp}`;
    return crypto.createHash('sha256').update(payload).digest('hex');
  }

  async log({ householdId, action, actor = 'system', details = {}, ipAddress = '127.0.0.1' }) {
    const timestamp = new Date().toISOString();
    const entry = {
      householdId,
      action,
      actor,
      ipAddress,
      details,
      timestamp
    };
    
    const hash = this._computeHash(entry);
    this.lastHash = hash;

    const auditDoc = await db.collection('AuditLog').create({
      ...entry,
      hash
    });

    console.log(`[AUDIT] [${action}] by ${actor} (Hash: ${hash.substring(0, 12)}...)`);
    return auditDoc;
  }

  async getLogs(householdId, limit = 50) {
    const logs = await db.collection('AuditLog').find({ householdId });
    return logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)).slice(0, limit);
  }
}

export const auditService = new AuditService();

