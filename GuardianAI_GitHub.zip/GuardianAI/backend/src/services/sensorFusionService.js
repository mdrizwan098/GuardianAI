import { db } from '../config/database.js';

class SensorFusionService {
  constructor() {
    this.recentSignals = []; // Sliding window of telemetry signals
    this.WINDOW_MS = 20000; // 20-second temporal correlation window
  }

  _cleanupOldSignals() {
    const now = Date.now();
    this.recentSignals = this.recentSignals.filter(s => now - s.timestamp < this.WINDOW_MS);
  }

  async processIncomingSignal({ householdId, deviceId, eventType, rawConfidence = 0.8, telemetryData = {} }) {
    this._cleanupOldSignals();

    // Check Privacy Mode
    const household = await db.collection('Household').findById(householdId);
    if (household && household.privacyModeActive) {
      if (['fall_detected', 'audio_distress'].includes(eventType)) {
        console.log(`[SENSOR FUSION] Signal ${eventType} rejected due to active Privacy Mode.`);
        return {
          admitted: false,
          reason: 'PRIVACY_MODE_ACTIVE',
          riskLevel: null
        };
      }
    }

    const currentSignal = {
      householdId,
      deviceId,
      eventType,
      rawConfidence,
      telemetryData,
      timestamp: Date.now()
    };
    this.recentSignals.push(currentSignal);

    // Save SensorEvent record
    await db.collection('SensorEvent').create({
      householdId,
      deviceId,
      eventType,
      rawConfidence,
      telemetryData,
      isProcessed: true
    });

    // Evaluate correlation
    return this.evaluateThreat(householdId, currentSignal);
  }

  evaluateThreat(householdId, triggerSignal) {
    const householdSignals = this.recentSignals.filter(s => s.householdId === householdId);
    const eventType = triggerSignal.eventType;

    let riskLevel = 'LEVEL_1_INFO';
    let assessedConfidence = triggerSignal.rawConfidence;
    let primaryReason = `Detected ${eventType}`;
    let corroboratingSignals = [];
    let requiresVoiceChallenge = false;
    let immediateCritical = false;

    // Rule 1: Smoke / Fire Alarm -> Instant Level 3
    if (eventType === 'smoke_detected') {
      riskLevel = 'LEVEL_3_CRITICAL';
      assessedConfidence = Math.max(triggerSignal.rawConfidence, 0.95);
      primaryReason = 'Fire / Smoke alarm activation confirmed';
      immediateCritical = true;
    }

    // Rule 2: Fall Detection Kinematics -> Level 2 Warning (Voice challenge + 30s timer)
    else if (eventType === 'fall_detected') {
      riskLevel = 'LEVEL_2_WARNING';
      requiresVoiceChallenge = true;
      primaryReason = 'Kinematic analysis indicates sudden fall followed by motionless dwell time';
      
      // Corroborate with audio distress
      const distressSignal = householdSignals.find(s => s.eventType === 'audio_distress');
      if (distressSignal) {
        corroboratingSignals.push({ sensorType: 'audio_distress', signalValue: 'Cries/Groans detected' });
        assessedConfidence = Math.min(0.98, assessedConfidence + 0.15);
      }
    }

    // Rule 3: Intrusion Indicators (Door Forced or Door Open + Glass Break / Motion)
    else if (eventType === 'door_forced') {
      riskLevel = 'LEVEL_3_CRITICAL';
      assessedConfidence = Math.max(triggerSignal.rawConfidence, 0.90);
      primaryReason = 'Forced entry structural vibration or lock breach detected';
      immediateCritical = true;
    }
    else if (eventType === 'glass_break') {
      const doorSignal = householdSignals.find(s => s.eventType === 'door_open' || s.eventType === 'motion');
      if (doorSignal) {
        riskLevel = 'LEVEL_3_CRITICAL';
        assessedConfidence = 0.92;
        primaryReason = 'Acoustic glass break correlated with subsequent motion/door activity';
        corroboratingSignals.push({ sensorType: doorSignal.eventType, signalValue: 'Movement detected post-impact' });
        immediateCritical = true;
      } else {
        riskLevel = 'LEVEL_2_WARNING';
        primaryReason = 'Acoustic glass break resonance detected';
      }
    }

    // Rule 4: Audio Distress (calls for help / screams)
    else if (eventType === 'audio_distress') {
      riskLevel = 'LEVEL_2_WARNING';
      requiresVoiceChallenge = true;
      primaryReason = 'Acoustic distress keywords detected (help / bachao / shouting)';
      
      const motionSignal = householdSignals.find(s => s.eventType === 'motion' || s.eventType === 'fall_detected');
      if (motionSignal) {
        corroboratingSignals.push({ sensorType: motionSignal.eventType, signalValue: 'Physical motion correlation' });
        assessedConfidence = Math.min(0.95, assessedConfidence + 0.12);
      }
    }

    // Rule 5: Standard Door Open / Routine Motion -> Level 1
    else if (eventType === 'door_open' || eventType === 'motion') {
      riskLevel = 'LEVEL_1_INFO';
      primaryReason = `Routine ${eventType} event logged`;
    }

    return {
      admitted: true,
      riskLevel,
      assessedConfidence: Number(assessedConfidence.toFixed(2)),
      primaryReason,
      corroboratingSignals,
      requiresVoiceChallenge,
      immediateCritical
    };
  }
}

export const sensorFusionService = new SensorFusionService();

