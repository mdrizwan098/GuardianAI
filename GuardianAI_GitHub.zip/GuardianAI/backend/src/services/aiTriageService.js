import { db } from '../config/database.js';
import { escalationEngine } from './escalationEngine.js';
import { emergencyDispatchService } from './emergencyDispatchService.js';
import { auditService } from './auditService.js';

class AITriageService {
  async processConversationalTriage({ householdId, userMessage, language = 'en' }) {
    const text = (userMessage || '').trim().toLowerCase();
    const household = await db.collection('Household').findById(householdId);
    const familyMembers = await db.collection('FamilyMember').find({ householdId });
    const contacts = await db.collection('EmergencyContact').find({ householdId });

    let responseText = '';
    let suggestedAction = null;
    let actionTriggered = null;
    let urgencyLevel = 'NORMAL';

    // 1. Check for immediate emergency/SOS commands
    if (
      text.includes('fall') || text.includes('gir gaya') || text.includes('giri hoon') ||
      text.includes('fell') || text.includes('unconscious') || text.includes('behosh')
    ) {
      urgencyLevel = 'CRITICAL';
      responseText = language === 'hi'
        ? "मैं आपके साथ हूँ। क्या आपको चक्कर आ रहा है या सांस लेने में तकलीफ है? मैंने आपके परिवार को सतर्क कर दिया है।"
        : language === 'hinglish'
        ? "Main aapke saath hoon. Kya aapko saans lene mein takleef ho rahi hai ya behoshi jaisa lag raha hai? Maine emergency contact ko alert kiya hai."
        : "I'm right here with you. Are you experiencing severe pain, dizziness, or trouble breathing? I have alerted your registered emergency contacts.";
      
      suggestedAction = 'CALL_PRIMARY_CONTACT';
      
      // Trigger Level 2 emergency
      await escalationEngine.triggerEmergency({
        householdId,
        eventType: 'medical_fall',
        riskLevel: 'LEVEL_2_WARNING',
        confidenceScore: 0.88,
        primaryReason: 'User reported fall via conversational voice assistant'
      });
      actionTriggered = 'LEVEL_2_EMERGENCY_TRIGGERED';
    }

    // 2. Door breach / intruder threat
    else if (
      text.includes('door') && (text.includes('open') || text.includes('someone') || text.includes('trying') || text.includes('khol') || text.includes('koi')) ||
      text.includes('intruder') || text.includes('thief') || text.includes('chor') || text.includes('darwaza')
    ) {
      urgencyLevel = 'CRITICAL';
      const safeRoom = household?.safeRoomLocation || 'a secure locked room';
      responseText = language === 'hi'
        ? `कृपया तुरंत सुरक्षित स्थान (${safeRoom}) में जाएं और दरवाजा बंद कर लें। क्या मैं पुलिस (112) को कॉल करूँ?`
        : language === 'hinglish'
        ? `Please turant safe room (${safeRoom}) mein move ho jayein. Main aapke registered emergency contacts aur Police 112 ko alert kar rahi hoon.`
        : `Please move to a safe place immediately (${safeRoom}) and lock the door if possible. I can alert your emergency contacts and police right now.`;
      
      suggestedAction = 'DISPATCH_POLICE_112';

      await escalationEngine.triggerEmergency({
        householdId,
        eventType: 'intrusion_attempt',
        riskLevel: 'LEVEL_3_CRITICAL',
        confidenceScore: 0.92,
        primaryReason: 'Resident reported active door breach / unauthorized entry'
      });
      actionTriggered = 'LEVEL_3_EMERGENCY_TRIGGERED';
    }

    // 3. Call son / daughter / spouse / doctor
    else if (text.includes('call') || text.includes('phone') || text.includes('mila do') || text.includes('lagao')) {
      if (text.includes('son') || text.includes('beta') || text.includes('aarav') || text.includes('family')) {
        const primary = contacts.find(c => c.priorityOrder === 1) || contacts[0];
        responseText = language === 'hi'
          ? `आपके बेटे ${primary?.name || 'इमर्जेंसी संपर्क'} को तुरंत कॉल मिलाया जा रहा है।`
          : language === 'hinglish'
          ? `Aapke bete ${primary?.name || 'Primary Contact'} ko call connect ki ja rahi hai...`
          : `Calling your son (${primary?.name || 'primary contact'}) now. Please stay calm.`;
        suggestedAction = 'INITIATE_FAMILY_CALL';
        actionTriggered = 'FAMILY_CALL_INITIATED';
      } else if (text.includes('doctor') || text.includes('hospital')) {
        const doc = contacts.find(c => c.contactType === 'doctor') || contacts[0];
        responseText = language === 'hi'
          ? `आपके पारिवारिक डॉक्टर ${doc?.name || 'डॉक्टर'} से संपर्क स्थापित किया जा रहा है।`
          : language === 'hinglish'
          ? `Aapke registered doctor ${doc?.name || 'Dr. Gupta'} se connect kar rahe hain.`
          : `Connecting you with your registered physician (${doc?.name || 'Dr. Gupta'}) right away.`;
        suggestedAction = 'CONNECT_DOCTOR';
        actionTriggered = 'DOCTOR_CALL_INITIATED';
      } else {
        responseText = language === 'hi'
          ? "मैं आपके प्राथमिक आपातकालीन संपर्क को कॉल मिला रही हूँ।"
          : "Connecting to your primary emergency contact right now.";
        suggestedAction = 'INITIATE_FAMILY_CALL';
      }
    }

    // 4. Weakness / medical distress
    else if (text.includes('weak') || text.includes('kamzor') || text.includes('breath') || text.includes('chest') || text.includes('pain') || text.includes('dard')) {
      urgencyLevel = 'HIGH';
      responseText = language === 'hi'
        ? "मैं आपके साथ हूँ। कृपया आराम से बैठ जाएँ। क्या सीने में दर्द है या सांस फूल रही है? क्या मैं डॉक्टर को बुलाऊं?"
        : language === 'hinglish'
        ? "Main aapke saath hoon. Please aaram se baith jayein. Kya chest pain ho raha hai ya saans phool rahi hai? Kya main doctor ko connect karun?"
        : "I am here with you. Please sit or lie down comfortably. Are you having chest tightness or difficulty breathing? I can connect you with your doctor or emergency services.";
      suggestedAction = 'CONNECT_DOCTOR';
    }

    // 5. User confirms safety
    else if (text.includes('fine') || text.includes('ok') || text.includes('theek') || text.includes('safe') || text.includes('all good')) {
      responseText = language === 'hi'
        ? "यह जानकर राहत मिली कि आप सुरक्षित हैं। मैं निगरानी जारी रख रही हूँ।"
        : language === 'hinglish'
        ? "Glad to know aap theek hain! Main active monitoring continue kar rahi hoon. Koi bhi zaroorat ho to batayein."
        : "Glad to hear that you are alright. GuardianAI is continuing to monitor your home safely.";
      suggestedAction = 'DISMISS_ALERT';
      
      // If there's an active emergency, resolve it
      const activeEvt = await db.collection('EmergencyEvent').findOne({ householdId, resolutionStatus: 'active' });
      if (activeEvt) {
        await escalationEngine.confirmEmergency(householdId, activeEvt.eventId, true, 'User confirmed safe via voice');
      }
    }

    // 6. General home safety queries
    else if (text.includes('status') || text.includes('kya chal raha') || text.includes('security')) {
      const activeCount = await db.collection('EmergencyEvent').countDocuments({ householdId, resolutionStatus: 'active' });
      responseText = language === 'hi'
        ? `घर की स्थिति: ${activeCount > 0 ? 'सक्रिय चेतावनी चालू है' : 'सभी सेंसर सामान्य हैं'}। सभी कमरे सुरक्षित हैं।`
        : language === 'hinglish'
        ? `Ghar ka status: ${activeCount > 0 ? 'Active alerts chal rahe hain' : 'Sabhi sensors safe and normal hain'}.`
        : `Home status: ${activeCount > 0 ? 'Active emergency alert in progress' : 'All smart sensors and cameras are secure and normal'}.`;
    }

    // 7. General fallback
    else {
      responseText = language === 'hi'
        ? "मैं आपकी बात सुन रही हूँ। अगर आपको कोई सहायता, डॉक्टर या परिवार से संपर्क चाहिए तो मुझे बताएं।"
        : language === 'hinglish'
        ? "Main sun rahi hoon. Agar aapko koi help chahiye ya doctor/family ko call karna ho, toh bataiye."
        : "I'm listening. If you feel unwell, notice anything unusual, or need to connect to your family or doctor, simply tell me.";
    }

    await auditService.log({
      householdId,
      action: 'AI_CONVERSATION_TRIAGE',
      actor: 'ai_assistant',
      details: { userMessage, responseText, urgencyLevel, actionTriggered }
    });

    return {
      message: responseText,
      urgencyLevel,
      suggestedAction,
      actionTriggered,
      language
    };
  }
}

export const aiTriageService = new AITriageService();

