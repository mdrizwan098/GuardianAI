import { db } from '../config/database.js';
import { ENV } from '../config/env.js';
import { auditService } from './auditService.js';

class NotificationService {
  async dispatch({ householdId, emergencyEventId, recipient, channel = 'sms', message }) {
    const timestamp = new Date().toISOString();
    const isSimulation = ENV.SMS_GATEWAY_MODE === 'simulation';
    
    // Create record
    const notifRecord = await db.collection('Notification').create({
      householdId,
      emergencyEventId,
      recipientName: recipient.name || 'Emergency Contact',
      recipientPhone: recipient.phone,
      channel,
      status: 'queued',
      dispatchTimestamp: timestamp,
      retryCount: 0
    });

    try {
      // In simulation mode, generate authentic telemetry receipt
      console.log(`\n======================================================`);
      console.log(`[NOTIFICATION DISPATCH] Mode: ${isSimulation ? 'SIMULATION' : 'LIVE'}`);
      console.log(`Channel: ${channel.toUpperCase()} | Recipient: ${recipient.name} (${recipient.phone})`);
      console.log(`Message: "${message}"`);
      console.log(`======================================================\n`);

      const deliveryReceipt = isSimulation 
        ? `SIM_SMS_${Math.random().toString(36).substring(2, 9).toUpperCase()}_DELIVERED`
        : `TEL_${Date.now()}`;

      await db.collection('Notification').findByIdAndUpdate(notifRecord._id, {
        status: isSimulation ? 'simulated' : 'delivered',
        deliveryReceipt
      });

      await auditService.log({
        householdId,
        action: 'NOTIFICATION_DISPATCHED',
        actor: 'notification_service',
        details: {
          recipientPhone: recipient.phone,
          channel,
          status: isSimulation ? 'simulated' : 'delivered',
          receipt: deliveryReceipt
        }
      });

      return {
        success: true,
        notificationId: notifRecord._id,
        status: isSimulation ? 'simulated' : 'delivered',
        receipt: deliveryReceipt,
        mode: isSimulation ? 'simulation' : 'live'
      };
    } catch (err) {
      console.error('[NOTIFICATION ERROR]', err);
      await db.collection('Notification').findByIdAndUpdate(notifRecord._id, {
        status: 'failed',
        retryCount: 1
      });
      return { success: false, error: err.message };
    }
  }

  async broadcastToHouseholdContacts(householdId, emergencyEventId, alertTitle, alertBody) {
    const contacts = await db.collection('EmergencyContact').find({ householdId });
    const sorted = contacts.sort((a, b) => (a.priorityOrder || 99) - (b.priorityOrder || 99));

    const results = [];
    for (const contact of sorted) {
      if (contact.notifyViaSms) {
        const res = await this.dispatch({
          householdId,
          emergencyEventId,
          recipient: contact,
          channel: 'sms',
          message: `[GUARDIAN-AI ALERT] ${alertTitle}: ${alertBody}. Location: Check household portal.`
        });
        results.push(res);
      }
    }
    return results;
  }
}

export const notificationService = new NotificationService();

