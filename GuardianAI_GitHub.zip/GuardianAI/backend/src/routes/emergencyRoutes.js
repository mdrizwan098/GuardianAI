import express from 'express';
import { db } from '../config/database.js';
import { cache } from '../config/cache.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { escalationEngine } from '../services/escalationEngine.js';
import { emergencyDispatchService } from '../services/emergencyDispatchService.js';
import { auditService } from '../services/auditService.js';

const router = express.Router();

router.get('/active', authenticate, async (req, res, next) => {
  try {
    const householdId = req.user.householdId;
    const activeEvent = await db.collection('EmergencyEvent').findOne({
      householdId,
      resolutionStatus: 'active'
    });

    if (!activeEvent) {
      return res.json({ active: false, event: null, countdown: 0 });
    }

    const countdown = await cache.get(`countdown:${activeEvent.eventId}`);
    const riskAssessment = await db.collection('RiskAssessment').findOne({
      emergencyEventId: activeEvent._id
    });

    res.json({
      active: true,
      event: activeEvent,
      countdown: countdown !== null ? Number(countdown) : 0,
      riskAssessment
    });
  } catch (err) {
    next(err);
  }
});

router.post('/confirm', authenticate, async (req, res, next) => {
  try {
    const { eventId, isSafe, notes } = req.body;
    if (!eventId) return res.status(400).json({ error: 'eventId is required' });

    const updated = await escalationEngine.confirmEmergency(req.user.householdId, eventId, !!isSafe, notes);
    res.json({ success: true, event: updated });
  } catch (err) {
    next(err);
  }
});

router.post('/escalate', authenticate, async (req, res, next) => {
  try {
    const { eventId, reason } = req.body;
    let emergency = null;
    
    if (eventId) {
      emergency = await db.collection('EmergencyEvent').findOne({ eventId });
    }

    if (!emergency) {
      // Trigger new Level 3 Critical emergency
      emergency = await escalationEngine.triggerEmergency({
        householdId: req.user.householdId,
        eventType: 'panic_button',
        riskLevel: 'LEVEL_3_CRITICAL',
        confidenceScore: 1.0,
        primaryReason: reason || 'Manual Emergency SOS Activated by User'
      });
    } else {
      await escalationEngine.handleCountdownExpiry(req.user.householdId, emergency, 'LEVEL_2_WARNING');
    }

    res.json({ success: true, message: 'Escalated to Level 3 Critical', event: emergency });
  } catch (err) {
    next(err);
  }
});

router.post('/dispatch-112', authenticate, async (req, res, next) => {
  try {
    const { eventId, serviceType = 'ALL', triggerReason = 'User requested 112 emergency dispatch' } = req.body;
    let emergency = null;
    if (eventId) {
      emergency = await db.collection('EmergencyEvent').findOne({ eventId });
    }

    const result = await emergencyDispatchService.dispatch112({
      householdId: req.user.householdId,
      emergencyEventId: emergency ? emergency._id : null,
      serviceType,
      triggerReason
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.post('/connect-doctor', authenticate, async (req, res, next) => {
  try {
    const { eventId, doctorContactId } = req.body;
    let doctorId = doctorContactId;
    if (!doctorId) {
      const doc = await db.collection('EmergencyContact').findOne({
        householdId: req.user.householdId,
        contactType: 'doctor'
      });
      doctorId = doc ? doc._id : null;
    }

    if (!doctorId) {
      return res.status(404).json({ error: 'No registered physician found in household contacts' });
    }

    const result = await emergencyDispatchService.connectDoctor({
      householdId: req.user.householdId,
      emergencyEventId: eventId,
      doctorContactId: doctorId
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.get('/history', authenticate, async (req, res, next) => {
  try {
    const events = await db.collection('EmergencyEvent').find({ householdId: req.user.householdId });
    events.sort((a, b) => new Date(b.detectionTimestamp) - new Date(a.detectionTimestamp));
    res.json(events);
  } catch (err) {
    next(err);
  }
});

export default router;

