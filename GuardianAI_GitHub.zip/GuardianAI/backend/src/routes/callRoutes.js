import express from 'express';
import { db } from '../config/database.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { auditService } from '../services/auditService.js';

const router = express.Router();

router.post('/initiate', authenticate, async (req, res, next) => {
  try {
    const { receiverId, callType = 'family_video' } = req.body;
    const sessionToken = `call_room_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    const callDoc = await db.collection('Call').create({
      householdId: req.user.householdId,
      callerId: req.user._id,
      receiverId,
      callType,
      sessionToken,
      status: 'initiated',
      startedAt: new Date().toISOString()
    });

    await auditService.log({
      householdId: req.user.householdId,
      action: 'CALL_INITIATED',
      actor: req.user.name,
      details: { callId: callDoc._id, callType, sessionToken }
    });

    res.status(201).json({
      success: true,
      call: callDoc,
      sessionToken
    });
  } catch (err) {
    next(err);
  }
});

router.patch('/:id/end', authenticate, async (req, res, next) => {
  try {
    const { durationSeconds } = req.body;
    const updated = await db.collection('Call').findByIdAndUpdate(req.params.id, {
      status: 'ended',
      endedAt: new Date().toISOString(),
      durationSeconds: Number(durationSeconds) || 0
    });
    res.json(updated);
  } catch (err) {
    next(err);
  }
});

router.get('/history', authenticate, async (req, res, next) => {
  try {
    const calls = await db.collection('Call').find({ householdId: req.user.householdId });
    calls.sort((a, b) => new Date(b.startedAt) - new Date(a.startedAt));
    res.json(calls);
  } catch (err) {
    next(err);
  }
});

export default router;

