import express from 'express';
import { db } from '../config/database.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { getIO } from '../config/socket.js';

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const devices = await db.collection('Device').find({ householdId: req.user.householdId });
    const cameras = await db.collection('CameraDevice').find({ householdId: req.user.householdId });
    
    // Attach camera specifics if device is a camera
    const enriched = devices.map(d => {
      if (d.deviceType === 'camera') {
        const cam = cameras.find(c => c.deviceId === d._id);
        return { ...d, cameraConfig: cam || null };
      }
      return d;
    });

    res.json(enriched);
  } catch (err) {
    next(err);
  }
});

router.post('/telemetry', async (req, res, next) => {
  try {
    const { deviceId, batteryLevel, isOnline, telemetryData } = req.body;
    const device = await db.collection('Device').findById(deviceId);
    if (!device) return res.status(404).json({ error: 'Device not found' });

    const updated = await db.collection('Device').findByIdAndUpdate(deviceId, {
      batteryLevel: batteryLevel !== undefined ? batteryLevel : device.batteryLevel,
      isOnline: isOnline !== undefined ? isOnline : device.isOnline,
      lastHeartbeat: new Date().toISOString()
    });

    const io = getIO();
    if (io) {
      io.to(`household:${device.householdId}`).emit('device:telemetry', {
        deviceId,
        batteryLevel: updated.batteryLevel,
        isOnline: updated.isOnline,
        telemetryData
      });
    }

    res.json({ success: true, device: updated });
  } catch (err) {
    next(err);
  }
});

export default router;

