import express from 'express';
import { db } from '../config/database.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { getIO } from '../config/socket.js';
import { auditService } from '../services/auditService.js';

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const members = await db.collection('FamilyMember').find({ householdId: req.user.householdId });
    res.json(members);
  } catch (err) {
    next(err);
  }
});

router.post('/', authenticate, async (req, res, next) => {
  try {
    const { fullName, relationship, isChild, age, medicalConditions, emergencyPriority, avatarUrl } = req.body;
    const member = await db.collection('FamilyMember').create({
      householdId: req.user.householdId,
      fullName,
      relationship,
      isChild: !!isChild,
      age: Number(age) || 30,
      medicalConditions: Array.isArray(medicalConditions) ? medicalConditions : [medicalConditions || 'None'],
      emergencyPriority: Number(emergencyPriority) || 3,
      availabilityStatus: 'home',
      avatarUrl: avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
    });

    await auditService.log({
      householdId: req.user.householdId,
      action: 'FAMILY_MEMBER_ADDED',
      actor: req.user.name,
      details: { fullName, relationship }
    });

    res.status(201).json(member);
  } catch (err) {
    next(err);
  }
});

router.patch('/:id/status', authenticate, async (req, res, next) => {
  try {
    const { status } = req.body;
    const updated = await db.collection('FamilyMember').findByIdAndUpdate(req.params.id, {
      availabilityStatus: status
    });

    const io = getIO();
    if (io) {
      io.to(`household:${req.user.householdId}`).emit('family:status_changed', {
        memberId: req.params.id,
        availabilityStatus: status
      });
    }

    res.json(updated);
  } catch (err) {
    next(err);
  }
});

router.patch('/:id/medical', authenticate, async (req, res, next) => {
  try {
    const { medicalConditions } = req.body;
    const updated = await db.collection('FamilyMember').findByIdAndUpdate(req.params.id, {
      medicalConditions: Array.isArray(medicalConditions) ? medicalConditions : [medicalConditions]
    });
    res.json(updated);
  } catch (err) {
    next(err);
  }
});

export default router;

