import express from 'express';
import { authenticate } from '../middleware/authMiddleware.js';
import { aiTriageService } from '../services/aiTriageService.js';

const router = express.Router();

router.post('/triage', authenticate, async (req, res, next) => {
  try {
    const { message, language = 'en' } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message payload required' });
    }

    const triageResult = await aiTriageService.processConversationalTriage({
      householdId: req.user.householdId,
      userMessage: message,
      language
    });

    res.json(triageResult);
  } catch (err) {
    next(err);
  }
});

router.get('/prompts', authenticate, (req, res) => {
  const language = req.query.lang || 'en';
  
  const prompts = {
    en: [
      { text: "Help me, I am feeling very weak.", type: "medical" },
      { text: "Someone is trying to open my door.", type: "security" },
      { text: "Call my son.", type: "family" },
      { text: "Connect me with my doctor.", type: "medical" },
      { text: "I fell down and need assistance.", type: "fall" },
      { text: "I am fine, false alarm.", type: "safe" }
    ],
    hi: [
      { text: "मदद करो, मुझे बहुत कमजोरी लग रही है।", type: "medical" },
      { text: "कोई मेरा मुख्य दरवाजा खोलने की कोशिश कर रहा है।", type: "security" },
      { text: "मेरे बेटे को फोन लगाओ।", type: "family" },
      { text: "डॉक्टर साहब से बात कराओ।", type: "medical" },
      { text: "मैं गिर गया हूँ और उठ नहीं पा रहा।", type: "fall" },
      { text: "सब ठीक है, चिंता मत करो।", type: "safe" }
    ],
    hinglish: [
      { text: "Help me, mujhe bohot weakness lag rahi hai.", type: "medical" },
      { text: "Koi darwaza open karne ki koshish kar raha hai.", type: "security" },
      { text: "Mere bete ko turant call karo.", type: "family" },
      { text: "Doctor Rajesh Gupta ko connect karo.", type: "medical" },
      { text: "Main gir gaya hoon, help chahiye.", type: "fall" },
      { text: "Main theek hoon, sab safe hai.", type: "safe" }
    ]
  };

  res.json({
    language,
    suggestedPrompts: prompts[language] || prompts.en
  });
});

export default router;

