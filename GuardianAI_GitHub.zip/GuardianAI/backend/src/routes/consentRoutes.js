import express from 'express';
import { db } from '../config/database.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { auditService } from '../services/auditService.js';

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    let consent = await db.collection('ConsentRecord').findOne({ householdId: req.user.householdId });
    if (!consent) {
      consent = await db.collection('ConsentRecord').create({
        householdId: req.user.householdId,
        userId: req.user._id,
        cameraConsent: true,
        microphoneConsent: true,
        biometricFallConsent: true,
        emergencyDispatchConsent: true,
        dataRetentionDays: 7,
        lastSignedAt: new Date().toISOString(),
        ipAddress: req.ip || '127.0.0.1'
      });
    }
    res.json(consent);
  } catch (err) {
    next(err);
  }
});

router.put('/', authenticate, async (req, res, next) => {
  try {
    const { cameraConsent, microphoneConsent, biometricFallConsent, emergencyDispatchConsent, dataRetentionDays } = req.body;
    let consent = await db.collection('ConsentRecord').findOne({ householdId: req.user.householdId });
    
    const updateData = {
      cameraConsent: cameraConsent !== undefined ? !!cameraConsent : true,
      microphoneConsent: microphoneConsent !== undefined ? !!microphoneConsent : true,
      biometricFallConsent: biometricFallConsent !== undefined ? !!biometricFallConsent : true,
      emergencyDispatchConsent: emergencyDispatchConsent !== undefined ? !!emergencyDispatchConsent : true,
      dataRetentionDays: Number(dataRetentionDays) || 7,
      lastSignedAt: new Date().toISOString(),
      ipAddress: req.ip || '127.0.0.1'
    };

    if (consent) {
      consent = await db.collection('ConsentRecord').findByIdAndUpdate(consent._id, updateData);
    } else {
      consent = await db.collection('ConsentRecord').create({
        householdId: req.user.householdId,
        userId: req.user._id,
        ...updateData
      });
    }

    await auditService.log({
      householdId: req.user.householdId,
      action: 'PRIVACY_CONSENT_UPDATED',
      actor: req.user.name,
      details: updateData
    });

    res.json(consent);
  } catch (err) {
    next(err);
  }
});

export default router;

