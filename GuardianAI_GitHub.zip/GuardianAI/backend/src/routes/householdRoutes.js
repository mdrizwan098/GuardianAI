import express from 'express';
import { db } from '../config/database.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { getIO } from '../config/socket.js';
import { auditService } from '../services/auditService.js';

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const household = await db.collection('Household').findById(req.user.householdId);
    res.json(household);
  } catch (err) {
    next(err);
  }
});

router.patch('/privacy-mode', authenticate, async (req, res, next) => {
  try {
    const { active } = req.body;
    const household = await db.collection('Household').findByIdAndUpdate(req.user.householdId, {
      privacyModeActive: !!active
    });

    await auditService.log({
      householdId: req.user.householdId,
      action: active ? 'PRIVACY_MODE_ENABLED' : 'PRIVACY_MODE_DISABLED',
      actor: req.user.name,
      details: { privacyModeActive: !!active }
    });

    const io = getIO();
    if (io) {
      io.to(`household:${req.user.householdId}`).emit('privacy:toggled', {
        privacyModeActive: !!active,
        triggeredBy: req.user.name
      });
    }

    res.json({
      success: true,
      privacyModeActive: !!active,
      message: active ? 'Privacy Mode activated: Optical & Acoustic capture disabled' : 'Privacy Mode deactivated: Normal monitoring resumed'
    });
  } catch (err) {
    next(err);
  }
});

router.patch('/safe-room', authenticate, async (req, res, next) => {
  try {
    const { safeRoomLocation } = req.body;
    const household = await db.collection('Household').findByIdAndUpdate(req.user.householdId, {
      safeRoomLocation
    });
    res.json(household);
  } catch (err) {
    next(err);
  }
});

export default router;

