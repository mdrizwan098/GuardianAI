import express from 'express';
import { authenticate } from '../middleware/authMiddleware.js';
import { auditService } from '../services/auditService.js';

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const limit = Number(req.query.limit) || 100;
    const logs = await auditService.getLogs(req.user.householdId, limit);
    res.json(logs);
  } catch (err) {
    next(err);
  }
});

export default router;

