import express from 'express';
import { db } from '../config/database.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { auditService } from '../services/auditService.js';

const router = express.Router();

router.get('/', authenticate, async (req, res, next) => {
  try {
    const contacts = await db.collection('EmergencyContact').find({ householdId: req.user.householdId });
    contacts.sort((a, b) => (a.priorityOrder || 99) - (b.priorityOrder || 99));
    res.json(contacts);
  } catch (err) {
    next(err);
  }
});

router.post('/', authenticate, async (req, res, next) => {
  try {
    const { name, relationship, phone, email, contactType, priorityOrder, notifyViaSms, notifyViaCall } = req.body;
    const contact = await db.collection('EmergencyContact').create({
      householdId: req.user.householdId,
      name,
      relationship,
      phone,
      email,
      contactType: contactType || 'family',
      priorityOrder: Number(priorityOrder) || 1,
      notifyViaSms: notifyViaSms !== undefined ? !!notifyViaSms : true,
      notifyViaCall: notifyViaCall !== undefined ? !!notifyViaCall : true
    });

    await auditService.log({
      householdId: req.user.householdId,
      action: 'EMERGENCY_CONTACT_ADDED',
      actor: req.user.name,
      details: { name, phone, priorityOrder }
    });

    res.status(201).json(contact);
  } catch (err) {
    next(err);
  }
});

router.put('/:id', authenticate, async (req, res, next) => {
  try {
    const updated = await db.collection('EmergencyContact').findByIdAndUpdate(req.params.id, req.body);
    res.json(updated);
  } catch (err) {
    next(err);
  }
});

router.delete('/:id', authenticate, async (req, res, next) => {
  try {
    await db.collection('EmergencyContact').deleteOne({ _id: req.params.id });
    res.json({ success: true, message: 'Emergency contact removed' });
  } catch (err) {
    next(err);
  }
});

export default router;

