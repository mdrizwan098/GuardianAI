import express from 'express';
import { db } from '../config/database.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { sensorFusionService } from '../services/sensorFusionService.js';
import { escalationEngine } from '../services/escalationEngine.js';
import { getIO } from '../config/socket.js';

const router = express.Router();

router.post('/detect', authenticate, async (req, res, next) => {
  try {
    const { deviceId, eventType, rawConfidence = 0.85, telemetryData = {} } = req.body;
    const householdId = req.user.householdId;

    const evaluation = await sensorFusionService.processIncomingSignal({
      householdId,
      deviceId,
      eventType,
      rawConfidence,
      telemetryData
    });

    if (!evaluation.admitted) {
      return res.json({
        admitted: false,
        reason: evaluation.reason,
        message: 'Signal suppressed by Privacy Mode or filter.'
      });
    }

    // Trigger deterministic escalation based on risk level
    let emergencyEvent = null;
    if (evaluation.riskLevel === 'LEVEL_2_WARNING' || evaluation.riskLevel === 'LEVEL_3_CRITICAL') {
      emergencyEvent = await escalationEngine.triggerEmergency({
        householdId,
        eventType,
        riskLevel: evaluation.riskLevel,
        confidenceScore: evaluation.assessedConfidence,
        primaryReason: evaluation.primaryReason,
        corroboratingSignals: evaluation.corroboratingSignals
      });
    }

    // Broadcast raw sensor telemetry indicator
    const io = getIO();
    if (io) {
      io.to(`household:${householdId}`).emit('sensor:event', {
        eventType,
        deviceId,
        confidence: evaluation.assessedConfidence,
        riskLevel: evaluation.riskLevel,
        timestamp: new Date().toISOString()
      });
    }

    res.status(200).json({
      success: true,
      evaluation,
      emergencyEvent
    });
  } catch (err) {
    next(err);
  }
});

router.get('/recent', authenticate, async (req, res, next) => {
  try {
    const events = await db.collection('SensorEvent').find({ householdId: req.user.householdId });
    events.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    res.json(events.slice(0, 30));
  } catch (err) {
    next(err);
  }
});

export default router;

